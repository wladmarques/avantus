'use strict';

/**
 * Banco de horas da equipe.
 *
 * Regras:
 * - O tempo é contado enquanto o staff está **em serviço**: a sessão abre quando
 *   ele fica DISPONÍVEL e fecha quando passa para AUSENTE/INDISPONÍVEL
 *   (EM_ATENDIMENTO mantém a sessão aberta).
 * - Atraso = diferença entre o início real e o início do turno planejado.
 * - Saída antecipada = diferença entre o fim do turno e a saída real.
 * - Aviso por DM configurável (padrão 5 minutos) antes do turno começar.
 */
const { createLogger } = require('../../utils/logger');
const {
  formatDuration,
  formatTime,
  formatDate,
  dayKey,
  startOfDay,
  addDays,
  tzParts,
} = require('../../utils/time');
const { STAFF_STATUS } = require('../../config/theme');
const {
  normalizeShift,
  toShift,
  findActiveShift,
  findNextShift,
  shiftsByWeekday,
  weekParity,
  latenessFor,
  earlyLeaveFor,
  minutesToHHMM,
  occurrenceFor,
  weekdayOf,
  shiftAppliesToWeek,
} = require('./shiftSchedule');

const logger = createLogger('hourbank');

const DEFAULT_REMINDER_MINUTES = 5;
const DEFAULT_MAX_SESSION_HOURS = 12;

/** Converte "YYYY-MM-DD" em timestamp da meia-noite local. */
function parseDayStart(value, timeZone) {
  if (!value) return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value).trim());
  if (!match) return null;
  const [, year, month, day] = match;
  const utc = Date.UTC(Number(year), Number(month) - 1, Number(day), 12, 0, 0);
  return startOfDay(new Date(utc), timeZone);
}

class HourBankService {
  constructor({ db, repo, settings, gateway = null, notifications = null, staff = null, timeZone = undefined }) {
    this.db = db;
    this.repo = repo;
    this.settings = settings;
    this.gateway = gateway;
    this.notifications = notifications;
    this.staff = staff;
    this.timeZone = timeZone;
    this.timer = null;
  }

  /* ------------------------------------------------------------------ */
  /* Configuração                                                        */
  /* ------------------------------------------------------------------ */

  get enabled() {
    const value = this.settings.get('hour_bank_enabled');
    return value === undefined ? true : Boolean(value);
  }

  get reminderMinutes() {
    const value = Number(this.settings.get('hour_bank_reminder_minutes'));
    return Number.isFinite(value) && value >= 0 ? value : DEFAULT_REMINDER_MINUTES;
  }

  /* ------------------------------------------------------------------ */
  /* Não entrada em serviço (faltas e atrasos)                           */
  /* ------------------------------------------------------------------ */

  /**
   * Tolerância (minutos) depois do início do turno antes de registrar que o
   * staff não entrou em serviço. `0` desliga o registro automático.
   */
  get absenceGraceMinutes() {
    const value = Number(this.settings.get('hour_bank_absence_minutes'));
    if (!Number.isFinite(value) || value <= 0) return 0;
    return Math.min(240, Math.round(value));
  }

  /** Janela (horas) para recuperar turnos perdidos enquanto o bot estava fora. */
  get absenceCatchupHours() {
    const value = Number(this.settings.get('hour_bank_absence_catchup_hours'));
    if (!Number.isFinite(value) || value <= 0) return 0;
    return Math.min(72, Math.round(value));
  }

  /** Cargos avisados no Discord quando alguém não entra em serviço. */
  get absenceRoleIds() {
    const value = this.settings.get('hour_bank_absence_role_ids');
    if (!Array.isArray(value)) return [];
    return value.filter((id) => /^\d{17,20}$/.test(String(id))).map(String);
  }

  /**
   * Canal do aviso de não entrada em serviço.
   *
   * O aviso é registro administrativo, não conversa da equipe: vai para o canal
   * de **logs** (`hour_bank_absence_channel_id`, padrão = canal de log de
   * atendimento) e só cai no canal da staff se o de logs não estiver definido.
   */
  get absenceChannelId() {
    const value = this.settings.get('hour_bank_absence_channel_id');
    if (value && /^\d{17,20}$/.test(String(value))) return String(value);
    const logs = this.settings.get('log_channel_id');
    if (logs && /^\d{17,20}$/.test(String(logs))) return String(logs);
    return this.settings.get('staff_channel_id') ?? null;
  }

  get maxSessionHours() {
    const value = Number(this.settings.get('hour_bank_max_session_hours'));
    return Number.isFinite(value) && value > 0 ? value : DEFAULT_MAX_SESSION_HOURS;
  }

  /* ------------------------------------------------------------------ */
  /* Escala                                                              */
  /* ------------------------------------------------------------------ */

  listShifts(guildId, userId = undefined) {
    return this.repo.listShiftsSync(guildId, userId ?? null).map(toShift);
  }

  /**
   * Salva a escala semanal de um staff (substitui a anterior).
   * @param {{guildId: string, userId: string, staffName?: string, shifts: Array<{weekday:number,start:string,end:string}>}} params
   */
  async setSchedule({ guildId, userId, staffName = null, shifts = [] }) {
    const normalized = shifts.map(normalizeShift);
    await this.db.transaction(async () => {
      this.repo.replaceShiftsSync(guildId, userId, staffName, normalized);
      // O nome vale mesmo sem turno cadastrado (staff recém-adicionado).
      if (staffName) this.repo.upsertNameSync(guildId, userId, staffName, 'painel');
    });
    return this.listShifts(guildId, userId);
  }

  /* ------------------------------------------------------------------ */
  /* Nome exibido                                                        */
  /* ------------------------------------------------------------------ */

  /** Nomes exibidos por staff: Map<userId, nome>. */
  names(guildId) {
    const map = new Map();
    for (const row of this.repo.listNamesSync(guildId)) {
      if (row.staff_name) map.set(row.user_id, row.staff_name);
    }
    return map;
  }

  nameOf(guildId, userId) {
    const row = this.repo.findNameSync(guildId, userId);
    return row?.staff_name ?? null;
  }

  /**
   * Define o nome do staff pelo painel. String vazia/null remove o nome manual
   * (o painel volta a usar o nome do Discord).
   * @returns {Promise<string|null>}
   */
  async setDisplayName({ guildId, userId, staffName = null }) {
    const clean = typeof staffName === 'string' ? staffName.trim().replace(/\s+/g, ' ') : '';
    await this.db.transaction(async () => {
      if (clean) {
        this.repo.upsertNameSync(guildId, userId, clean.slice(0, 60), 'painel');
        // Mantém a escala coerente com o nome novo.
        this.db.run('UPDATE staff_shifts SET staff_name = ? WHERE guild_id = ? AND user_id = ?', [
          clean.slice(0, 60),
          guildId,
          userId,
        ]);
      } else {
        this.repo.deleteNameSync(guildId, userId);
      }
    });
    return clean ? clean.slice(0, 60) : null;
  }

  /** Nome vindo do próprio Discord (não sobrescreve um nome definido no painel). */
  rememberDiscordName(guildId, userId, staffName) {
    const clean = typeof staffName === 'string' ? staffName.trim() : '';
    if (!clean) return null;
    return this.repo.upsertNameSync(guildId, userId, clean.slice(0, 60), 'discord');
  }

  async clearSchedule({ guildId, userId }) {
    await this.db.transaction(async () => this.repo.deleteShiftsSync(guildId, userId));
  }

  /** Escala agrupada por dia (para o painel). */
  weeklySchedule(guildId, userId) {
    return shiftsByWeekday(this.listShifts(guildId, userId));
  }

  /* ------------------------------------------------------------------ */
  /* Sessões                                                             */
  /* ------------------------------------------------------------------ */

  activeSession(guildId, userId) {
    const row = this.repo.findOpenSync(guildId, userId);
    if (!row) return null;
    return { ...row, elapsedSeconds: Math.max(0, Math.floor((Date.now() - row.started_at) / 1000)) };
  }

  /**
   * Abre a sessão de trabalho (idempotente).
   * @returns {Promise<object|null>} sessão aberta
   */
  async startSession({ guildId, userId, staffName = null, source = 'disponivel', at = Date.now() }) {
    if (!this.enabled) return null;
    const existing = this.repo.findOpenSync(guildId, userId);
    if (existing) return existing;

    const shifts = this.listShifts(guildId, userId);
    const active = findActiveShift(shifts, at, this.timeZone);
    const lateMinutes = active ? latenessFor(active, at) : 0;

    let resolvedName = staffName ?? shifts[0]?.staffName ?? null;
    if (!resolvedName && this.gateway?.getMember) {
      const member = await this.gateway.getMember(guildId, userId).catch(() => null);
      resolvedName = member?.displayName ?? null;
    }

    const created = await this.db.transaction(async () =>
      this.repo.openSync(guildId, userId, {
        staffName: resolvedName,
        startedAt: at,
        source,
        shift: active
          ? { shiftId: active.shift.shiftId, startTs: active.startTs, endTs: active.endTs, lateMinutes }
          : null,
      }),
    );

    // Se havia um registro de "não entrou em serviço" para este turno, a
    // chegada (mesmo atrasada) fecha o ciclo: o painel passa a mostrar
    // "atrasou X" em vez de "faltou".
    if (active) {
      await this.db.transaction(async () =>
        this.repo.markAbsenceReturnedSync(guildId, userId, { returnedAt: at, lateMinutes }),
      );
    }

    logger.info(
      `[banco de horas] ${resolvedName ?? userId} começou a contar${lateMinutes ? ` (atraso de ${lateMinutes} min)` : ''}.`,
    );
    return created;
  }

  /**
   * Fecha a sessão aberta (idempotente).
   * @returns {Promise<object|null>} sessão fechada
   */
  async endSession({ guildId, userId, at = Date.now() }) {
    const open = this.repo.findOpenSync(guildId, userId);
    if (!open) return null;

    const endedAt = Math.max(at, open.started_at);
    const minutes = Math.max(0, Math.round((endedAt - open.started_at) / 60000));
    const shift =
      open.scheduled_start !== null && open.scheduled_start !== undefined
        ? { startTs: Number(open.scheduled_start), endTs: Number(open.scheduled_end) }
        : null;
    const earlyLeaveMinutes = shift ? earlyLeaveFor(shift, endedAt) : 0;

    const closed = await this.db.transaction(async () =>
      this.repo.closeSync(open.id, { endedAt, minutes, earlyLeaveMinutes }),
    );
    logger.info(
      `[banco de horas] ${open.staff_name ?? userId} encerrou a sessão com ${formatDuration(minutes * 60)}.`,
    );
    return closed;
  }

  /**
   * Chamado quando o status do staff muda: abre/fecha a sessão conforme a
   * presença em serviço. Nunca lança erro para não travar a troca de status.
   */
  async syncStatus({ guildId, userId, staffName = null, status }) {
    if (!this.enabled) return null;
    try {
      if (status === STAFF_STATUS.DISPONIVEL) {
        return await this.startSession({ guildId, userId, staffName, source: 'status:disponivel' });
      }
      if (status === STAFF_STATUS.AUSENTE || status === STAFF_STATUS.INDISPONIVEL) {
        return await this.endSession({ guildId, userId });
      }
      // EM_ATENDIMENTO: continua contando (o staff segue em serviço).
      return null;
    } catch (error) {
      logger.error('Falha ao sincronizar o banco de horas com o status', error);
      return null;
    }
  }

  /** Fecha sessões esquecidas abertas (proteção contra queda do bot). */
  async closeStaleSessions(guildId, now = Date.now()) {
    const limit = this.maxSessionHours * 3600000;
    const open = this.repo.listOpenSync(guildId).filter((row) => now - row.started_at > limit);
    for (const row of open) {
      await this.endSession({ guildId, userId: row.user_id, at: row.started_at + limit });
      logger.warn(
        `[banco de horas] Sessão de ${row.staff_name ?? row.user_id} fechada automaticamente (limite de ${this.maxSessionHours}h).`,
      );
    }
    return open.length;
  }

  /* ------------------------------------------------------------------ */
  /* Avisos antes do turno                                               */
  /* ------------------------------------------------------------------ */

  /**
   * Procura turnos que começam dentro da antecedência configurada e devolve os
   * que ainda não receberam aviso.
   */
  dueReminders(guildId, now = Date.now()) {
    const minutes = this.reminderMinutes;
    if (minutes <= 0) return [];

    const horizon = minutes * 60000;
    const shifts = this.listShifts(guildId);
    const byUser = new Map();
    for (const shift of shifts) {
      if (!byUser.has(shift.userId)) byUser.set(shift.userId, []);
      byUser.get(shift.userId).push(shift);
    }

    const due = [];
    for (const [userId, userShifts] of byUser) {
      const next = findNextShift(userShifts, now, {
        horizonMs: horizon + 60 * 1000,
        timeZone: this.timeZone,
      });
      if (!next) continue;
      // Só avisa se o turno começa daqui a até X minutos (e ainda não começou).
      const diff = next.startTs - now;
      if (diff < 0 || diff > horizon) continue;
      if (this.repo.wasReminderSentSync(guildId, userId, next.shift.shiftId, next.dayKey)) continue;
      due.push({ userId, staffName: next.shift.staffName, occurrence: next, minutesAhead: Math.round(diff / 60000) });
    }
    return due;
  }

  /** Envia os avisos pendentes por DM. */
  async dispatchReminders(guildId, now = Date.now()) {
    const due = this.dueReminders(guildId, now);
    for (const item of due) {
      const { occurrence } = item;
      try {
        if (this.notifications?.shiftReminder) {
          await this.notifications.shiftReminder({
            guildId,
            userId: item.userId,
            shift: occurrence.shift,
            startsAt: occurrence.startTs,
            minutesAhead: this.reminderMinutes,
          });
        }
        await this.db.transaction(async () =>
          this.repo.markReminderSentSync(
            guildId,
            item.userId,
            occurrence.shift.shiftId,
            occurrence.dayKey,
            now,
          ),
        );
      } catch (error) {
        logger.warn(`Falha ao avisar ${item.userId} sobre o turno: ${error.message}`);
      }
    }
    return due.length;
  }

  /* ------------------------------------------------------------------ */
  /* Não entrada em serviço                                              */
  /* ------------------------------------------------------------------ */

  /**
   * Ocorrências de turno em que o staff **não entrou em serviço** no horário.
   *
   * Regra: passou a tolerância (`hour_bank_absence_minutes`) do início do turno
   * e nenhuma sessão de trabalho do staff encostou na janela do turno. Quem
   * começou a contar horas antes do turno (já disponível) conta como presente.
   *
   * Turnos que terminaram antes do bot subir também entram, dentro da janela
   * `hour_bank_absence_catchup_hours` — é o que faz o painel registrar a falta
   * mesmo se o bot estava reiniciando no horário marcado.
   *
   * @returns {Array<{userId: string, staffName: string|null, shift: object,
   *   startTs: number, endTs: number, dayKey: string, lateMinutes: number,
   *   ended: boolean}>}
   */
  dueAbsences(guildId, now = Date.now()) {
    const graceMinutes = this.absenceGraceMinutes;
    if (!graceMinutes) return [];
    const graceMs = graceMinutes * 60000;
    const catchupMs = this.absenceCatchupHours * 3600000;

    const shifts = this.listShifts(guildId);
    if (shifts.length === 0) return [];

    // Staff bloqueado pela administração não pode entrar em serviço: cobrar
    // falta dele seria injusto (e o painel já mostra o bloqueio).
    const blocked = new Set();
    if (typeof this.staff?.list === 'function') {
      for (const row of this.staff.list(guildId)) {
        if (row.blocked) blocked.add(row.userId);
      }
    }

    const shiftsByUser = new Map();
    for (const shift of shifts) {
      if (!shiftsByUser.has(shift.userId)) shiftsByUser.set(shift.userId, []);
      shiftsByUser.get(shift.userId).push(shift);
    }

    // Sessões dos últimos dias bastam para saber se o staff apareceu no turno.
    const sessionsByUser = new Map();
    const since = now - 2 * 24 * 3600000 - catchupMs;
    for (const row of this.repo.listSessionsSync(guildId, { from: since, to: now })) {
      if (!sessionsByUser.has(row.user_id)) sessionsByUser.set(row.user_id, []);
      sessionsByUser.get(row.user_id).push(row);
    }

    const due = [];
    for (const [userId, userShifts] of shiftsByUser) {
      if (blocked.has(userId)) continue;
      const sessions = sessionsByUser.get(userId) ?? [];
      for (const shift of userShifts) {
        // offset -1 cobre turnos que começaram ontem e viram a meia-noite.
        for (const offset of [-1, 0]) {
          if (weekdayOf(now, offset, this.timeZone) !== shift.weekday) continue;
          const occurrence = occurrenceFor(shift, now, offset, this.timeZone);
          if (!shiftAppliesToWeek(shift, occurrence.startTs, this.timeZone)) continue;
          if (now < occurrence.startTs + graceMs) continue;
          if (now > occurrence.endTs + catchupMs) continue;

          const windowEnd = Math.min(now, occurrence.endTs);
          const present = sessions.some(
            (session) =>
              session.started_at <= windowEnd &&
              (session.ended_at === null || session.ended_at === undefined || session.ended_at >= occurrence.startTs),
          );
          if (present) continue;
          if (this.repo.findAbsenceSync(guildId, userId, shift.shiftId, occurrence.dayKey)) continue;

          due.push({
            userId,
            staffName: shift.staffName ?? null,
            shift,
            startTs: occurrence.startTs,
            endTs: occurrence.endTs,
            dayKey: occurrence.dayKey,
            lateMinutes: Math.max(0, Math.round((now - occurrence.startTs) / 60000)),
            ended: now >= occurrence.endTs,
          });
        }
      }
    }
    return due;
  }

  /** Grava os registros de ausência pendentes (idempotente). */
  async registerAbsences(guildId, now = Date.now()) {
    const due = this.dueAbsences(guildId, now);
    if (due.length === 0) return [];
    const names = this.names(guildId);
    const created = [];
    for (const item of due) {
      const row = await this.db.transaction(async () =>
        this.repo.openAbsenceSync(guildId, item.userId, {
          staffName: names.get(item.userId) ?? item.staffName,
          shiftId: item.shift.shiftId,
          shiftDay: item.dayKey,
          scheduledStart: item.startTs,
          scheduledEnd: item.endTs,
          detectedAt: now,
        }),
      );
      if (!row) continue;
      created.push({ ...item, record: row });
      logger.warn(
        `[banco de horas] ${row.staff_name ?? item.userId} não entrou em serviço no turno ` +
          `${item.shift.start} às ${item.shift.end} (${formatDate(new Date(item.startTs), this.timeZone)}).`,
      );
    }
    return created;
  }

  /**
   * Avisa os cargos configurados sobre quem não entrou em serviço.
   * Cada registro recebe **um** aviso (marcado em `notified_at`), então
   * reiniciar o bot não repete a mensagem.
   */
  async dispatchAbsenceAlerts(guildId, now = Date.now()) {
    await this.registerAbsences(guildId, now);
    const pending = this.repo.listPendingAbsencesSync(guildId);
    if (pending.length === 0) return 0;

    const channelId = this.absenceChannelId;
    const roleIds = this.absenceRoleIds;
    if (!channelId || !this.notifications?.shiftAbsence) return 0;

    let sent = 0;
    for (const row of pending) {
      try {
        const lateMinutes = Math.max(0, Math.round((now - row.scheduled_start) / 60000));
        await this.notifications.shiftAbsence({
          guildId,
          channelId,
          roleIds,
          userId: row.user_id,
          staffName: row.staff_name,
          startsAt: row.scheduled_start,
          endsAt: row.scheduled_end,
          lateMinutes,
          ended: now >= row.scheduled_end,
        });
        await this.db.transaction(async () => this.repo.markAbsenceNotifiedSync(row.id, now));
        sent += 1;
      } catch (error) {
        logger.warn(`Falha ao avisar a ausência de ${row.user_id}: ${error.message}`);
      }
    }
    return sent;
  }

  /** Watcher: registra ausências e avisa os cargos. */
  async checkAbsences(guildId, now = Date.now()) {
    if (!this.enabled) return { registered: 0, notified: 0 };
    try {
      const registered = await this.registerAbsences(guildId, now);
      const notified = await this.dispatchAbsenceAlerts(guildId, now);
      return { registered: registered.length, notified };
    } catch (error) {
      logger.error('Falha ao registrar a não entrada em serviço', error);
      return { registered: 0, notified: 0 };
    }
  }

  /**
   * IDs de quem tem cadastro na equipe (status, nome ou escala).
   *
   * Serve para o histórico da seção Presença não mostrar quem foi removido do
   * quadro: `removeStaff` apaga esses três registros, então a pessoa sai da
   * lista mesmo continuando com o cargo no Discord (o cargo a traz de volta
   * para a EQUIPE, mas não para faltas/atrasos antigos).
   */
  teamIds(guildId) {
    const ids = new Set();
    try {
      if (this.staff) {
        for (const row of this.staff.list(guildId)) ids.add(row.userId);
      }
      for (const userId of this.names(guildId).keys()) ids.add(userId);
      for (const shift of this.listShifts(guildId)) ids.add(shift.userId);
    } catch {
      return null;
    }
    return ids;
  }

  /**
   * Lista as ausências do período com o estado já resolvido.
   *
   * - `ATRASOU`  → entrou em serviço depois do horário (compareceu)
   * - `ATRASADO` → o turno está correndo e a pessoa ainda não apareceu
   * - `FALTOU`   → o turno terminou sem ela
   */
  absences(guildId, { from = null, to = null, now = Date.now(), teamOnly = true } = {}) {
    // `teamOnly` (padrão): só quem está na equipe agora. Os registros de quem
    // foi removido do quadro continuam no banco, mas fora dos painéis.
    const team = teamOnly ? this.teamIds(guildId) : null;
    const rows = this.repo
      .listAbsencesSync(guildId, {
        from: from ?? now - 30 * 24 * 3600000,
        to: to ?? now,
      })
      .filter((row) => !team || team.has(row.user_id));

    return rows.map((row) => {
      const returned = row.returned_at !== null && row.returned_at !== undefined;
      const ended = now >= row.scheduled_end;
      const status = returned ? 'ATRASOU' : ended ? 'FALTOU' : 'ATRASADO';
      const lateMinutes = returned
        ? Number(row.returned_late_minutes) || 0
        : Math.max(0, Math.round((Math.min(now, row.scheduled_end) - row.scheduled_start) / 60000));
      const statusLabel =
        status === 'FALTOU'
          ? 'faltou'
          : status === 'ATRASOU'
            ? `atrasou ${formatDuration(lateMinutes * 60)}`
            : `atrasado há ${formatDuration(lateMinutes * 60)}`;

      return {
        id: row.id,
        userId: row.user_id,
        staffName: row.staff_name,
        day: formatDate(new Date(row.scheduled_start), this.timeZone),
        dayKey: row.shift_day,
        startLabel: formatTime(new Date(row.scheduled_start), this.timeZone),
        endLabel: formatTime(new Date(row.scheduled_end), this.timeZone),
        scheduledStart: row.scheduled_start,
        scheduledEnd: row.scheduled_end,
        detectedAt: row.detected_at,
        detectedLabel: formatTime(new Date(row.detected_at), this.timeZone),
        notifiedAt: row.notified_at ?? null,
        returnedAt: row.returned_at ?? null,
        returnedLabel: returned ? formatTime(new Date(row.returned_at), this.timeZone) : null,
        lateMinutes,
        status,
        statusLabel,
      };
    });
  }

  /** Watcher de 1 minuto: avisos + fechamento de sessões esquecidas. */
  startWatcher(guildId, { intervalMs = 60000 } = {}) {
    const tick = async () => {
      try {
        await this.dispatchReminders(guildId);
        await this.checkAbsences(guildId);
        await this.closeStaleSessions(guildId);
        this.repo.purgeRemindersSync();
      } catch (error) {
        logger.error('Falha no watcher do banco de horas', error);
      }
    };
    tick();
    const timer = setInterval(tick, intervalMs);
    timer.unref?.();
    this.timer = timer;
    return () => clearInterval(timer);
  }

  stopWatcher() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  /* ------------------------------------------------------------------ */
  /* Relatórios                                                          */
  /* ------------------------------------------------------------------ */

  /**
   * Relatório de horas por staff no período.
   * @param {{guildId: string, from?: string, to?: string}} params datas YYYY-MM-DD
   */
  report(guildId, { from = null, to = null, now = Date.now() } = {}) {
    const toTs = parseDayStart(to, this.timeZone);
    const fromTs = parseDayStart(from, this.timeZone);
    const startTs = fromTs ?? startOfDay(new Date(now - 6 * 24 * 3600000), this.timeZone);
    const endTs = toTs ? toTs + 24 * 3600000 - 1 : now;

    const rows = this.repo.listSessionsSync(guildId, { from: startTs, to: endTs });
    const shifts = this.listShifts(guildId);
    const names = this.names(guildId);
    const shiftsByUser = new Map();
    for (const shift of shifts) {
      if (!shiftsByUser.has(shift.userId)) shiftsByUser.set(shift.userId, []);
      shiftsByUser.get(shift.userId).push(shift);
    }

    const byUser = new Map();
    for (const row of rows) {
      const key = row.user_id;
      if (!byUser.has(key)) {
        byUser.set(key, {
          userId: row.user_id,
          staffName: row.staff_name ?? null,
          totalMinutes: 0,
          sessions: 0,
          lateCount: 0,
          lateMinutes: 0,
          earlyLeaveMinutes: 0,
          scheduledMinutes: 0,
          firstStart: null,
          lastEnd: null,
          days: new Map(),
        });
      }
      const entry = byUser.get(key);
      const endedAt = row.ended_at ?? now;
      const minutes = row.minutes !== null && row.minutes !== undefined
        ? Number(row.minutes)
        : Math.max(0, Math.round((endedAt - row.started_at) / 60000));

      entry.staffName = entry.staffName ?? row.staff_name ?? null;
      entry.totalMinutes += minutes;
      entry.sessions += 1;
      entry.lateMinutes += Number(row.late_minutes) || 0;
      entry.earlyLeaveMinutes += Number(row.early_leave_minutes) || 0;
      if ((Number(row.late_minutes) || 0) > 0) entry.lateCount += 1;
      if (row.scheduled_start && row.scheduled_end) {
        entry.scheduledMinutes += Math.round((Number(row.scheduled_end) - Number(row.scheduled_start)) / 60000);
      }
      if (entry.firstStart === null || row.started_at < entry.firstStart) entry.firstStart = row.started_at;
      if (entry.lastEnd === null || endedAt > entry.lastEnd) entry.lastEnd = endedAt;

      const key2 = dayKey(new Date(row.started_at), this.timeZone);
      const day = entry.days.get(key2) ?? { day: key2, minutes: 0, sessions: 0 };
      day.minutes += minutes;
      day.sessions += 1;
      entry.days.set(key2, day);
    }

    // Staff com escala ou só com nome cadastrado continua aparecendo no painel.
    for (const [userId, userShifts] of shiftsByUser) {
      if (byUser.has(userId)) continue;
      byUser.set(userId, {
        userId,
        staffName: names.get(userId) ?? userShifts[0]?.staffName ?? null,
        totalMinutes: 0,
        sessions: 0,
        lateCount: 0,
        lateMinutes: 0,
        earlyLeaveMinutes: 0,
        scheduledMinutes: 0,
        firstStart: null,
        lastEnd: null,
        days: new Map(),
      });
    }

    for (const userId of names.keys()) {
      if (byUser.has(userId)) continue;
      byUser.set(userId, {
        userId,
        staffName: names.get(userId),
        totalMinutes: 0,
        sessions: 0,
        lateCount: 0,
        lateMinutes: 0,
        earlyLeaveMinutes: 0,
        scheduledMinutes: 0,
        firstStart: null,
        lastEnd: null,
        days: new Map(),
      });
    }

    // Nome salvo no painel/Discord tem prioridade sobre o nome congelado na sessão.
    for (const entry of byUser.values()) {
      entry.staffName = names.get(entry.userId) ?? entry.staffName ?? null;
    }

    const staff = [...byUser.values()]
      .map((entry) => ({
        ...entry,
        days: [...entry.days.values()].sort((a, b) => a.day.localeCompare(b.day)),
        totalLabel: formatDuration(entry.totalMinutes * 60),
        averageLabel: entry.sessions ? formatDuration((entry.totalMinutes / entry.sessions) * 60) : '0s',
        entryLabel: entry.firstStart ? formatTime(new Date(entry.firstStart)) : '—',
        exitLabel: entry.lastEnd ? formatTime(new Date(entry.lastEnd)) : '—',
        shifts: (shiftsByUser.get(entry.userId) ?? []).map((shift) => ({
          weekday: shift.weekday,
          weekdayLabel: shift.weekdayLabel,
          start: shift.start,
          end: shift.end,
          overnight: shift.overnight,
          durationMinutes: shift.durationMinutes,
        })),
      }))
      .sort((a, b) => b.totalMinutes - a.totalMinutes || String(a.staffName).localeCompare(String(b.staffName)));

    return {
      period: {
        from: formatDate(new Date(startTs), this.timeZone),
        to: formatDate(new Date(endTs), this.timeZone),
        fromTs: startTs,
        toTs: endTs,
      },
      totals: {
        minutes: staff.reduce((sum, item) => sum + item.totalMinutes, 0),
        sessions: staff.reduce((sum, item) => sum + item.sessions, 0),
        lateCount: staff.reduce((sum, item) => sum + item.lateCount, 0),
        lateMinutes: staff.reduce((sum, item) => sum + item.lateMinutes, 0),
        staffCount: staff.length,
      },
      staff,
    };
  }

  /** Sessões detalhadas (entrada/saída/atraso) de um staff ou de todos. */
  sessions(guildId, { userId = null, from = null, to = null, now = Date.now() } = {}) {
    const toTs = parseDayStart(to, this.timeZone);
    const fromTs = parseDayStart(from, this.timeZone);
    const startTs = fromTs ?? startOfDay(new Date(now - 6 * 24 * 3600000), this.timeZone);
    const endTs = toTs ? toTs + 24 * 3600000 - 1 : now;

    return this.repo
      .listSessionsSync(guildId, { from: startTs, to: endTs, userId })
      .map((row) => {
        const endedAt = row.ended_at ?? null;
        const minutes = row.minutes !== null && row.minutes !== undefined
          ? Number(row.minutes)
          : Math.max(0, Math.round(((endedAt ?? now) - row.started_at) / 60000));
        return {
          id: row.id,
          userId: row.user_id,
          staffName: row.staff_name ?? null,
          day: dayKey(new Date(row.started_at), this.timeZone),
          startedAt: row.started_at,
          endedAt,
          entry: formatTime(new Date(row.started_at), this.timeZone),
          exit: endedAt ? formatTime(new Date(endedAt), this.timeZone) : null,
          minutes,
          label: formatDuration(minutes * 60),
          lateMinutes: Number(row.late_minutes) || 0,
          earlyLeaveMinutes: Number(row.early_leave_minutes) || 0,
          open: endedAt === null,
          scheduledStart: row.scheduled_start
            ? formatTime(new Date(Number(row.scheduled_start)), this.timeZone)
            : null,
          scheduledEnd: row.scheduled_end
            ? formatTime(new Date(Number(row.scheduled_end)), this.timeZone)
            : null,
          source: row.source ?? null,
        };
      });
  }

  /** Situação resumida de um staff (usada no comando /banco). */
  summary(guildId, userId, { now = Date.now() } = {}) {
    const todayStart = startOfDay(new Date(now), this.timeZone);
    const weekStart = todayStart - 6 * 24 * 3600000;
    const today = this.repo.listSessionsSync(guildId, { from: todayStart, to: now, userId });
    const week = this.repo.listSessionsSync(guildId, { from: weekStart, to: now, userId });
    const sum = (rows) =>
      rows.reduce((total, row) => {
        const minutes = row.minutes !== null && row.minutes !== undefined
          ? Number(row.minutes)
          : Math.max(0, Math.round(((row.ended_at ?? now) - row.started_at) / 60000));
        return total + minutes;
      }, 0);

    const lateMinutes = week.reduce((total, row) => total + (Number(row.late_minutes) || 0), 0);
    const lateCount = week.filter((row) => (Number(row.late_minutes) || 0) > 0).length;
    const active = this.activeSession(guildId, userId);
    const next = findNextShift(this.listShifts(guildId, userId), now, { timeZone: this.timeZone });
    const p = tzParts(new Date(now), this.timeZone);

    return {
      todayMinutes: sum(today),
      weekMinutes: sum(week),
      weekSessions: week.length,
      lateMinutes,
      lateCount,
      active,
      nextShift: next
        ? {
            weekdayLabel: next.shift.weekdayLabel,
            start: next.shift.start,
            end: next.shift.end,
            dayKey: next.dayKey,
            startTs: next.startTs,
            minutesAhead: Math.round((next.startTs - now) / 60000),
          }
        : null,
      shifts: this.listShifts(guildId, userId),
      todayLabel: formatDate(new Date(now), this.timeZone),
      nowLabel: `${String(p.hour).padStart(2, '0')}:${String(p.minute).padStart(2, '0')}`,
      todayStart,
      weekStart,
    };
  }

  /** Visão completa para o painel web: staff + status + escala + horas. */
  overview(guildId, { now = Date.now(), from = null, to = null } = {}) {
    if (!this.staff) return { staff: [], report: this.report(guildId, { from, to, now }) };

    const report = this.report(guildId, { from, to, now });
    const reportByUser = new Map(report.staff.map((item) => [item.userId, item]));
    const names = this.names(guildId);
    const shifts = this.listShifts(guildId);
    const shiftsByUser = new Map();
    for (const shift of shifts) {
      if (!shiftsByUser.has(shift.userId)) shiftsByUser.set(shift.userId, []);
      shiftsByUser.get(shift.userId).push(shift);
    }

    // Base da lista: **todos** os staff cadastrados + quem tem o cargo da
    // equipe no Discord e ainda não tem status (`staff_panel_role_ids`).
    //
    // Só `list()` escondia quem tem o cargo e nunca entrou em serviço (aparecia
    // na EQUIPE do Discord e sumia do painel web). Só `listForPanel()` escondia
    // os staff sem o cargo, que aqui formam o grupo "apoio".
    const registered = this.staff.list(guildId);
    const rosterOnly =
      typeof this.staff.rosterOnly === 'function'
        ? this.staff.rosterOnly(guildId, { exclude: new Set(registered.map((row) => row.userId)) })
        : [];
    const baseRows = [...registered, ...rosterOnly];

    const staffRows = new Map();
    for (const row of baseRows) {
      staffRows.set(row.userId, {
        userId: row.userId,
        staffName: null,
        status: row.status,
        statusLabel: row.meta?.label ?? row.status,
        available: row.status === STAFF_STATUS.DISPONIVEL,
        // Bloqueio administrativo: não entra em serviço até ser liberado.
        blocked: Boolean(row.blocked),
        blockedAt: row.blockedAt ?? null,
        blockedReason: row.blockedReason ?? null,
      });
    }
    for (const userId of [...shiftsByUser.keys(), ...names.keys()]) {
      if (!staffRows.has(userId)) {
        staffRows.set(userId, {
          userId,
          staffName: null,
          status: STAFF_STATUS.INDISPONIVEL,
          statusLabel: 'SEM STATUS',
          available: false,
          blocked: false,
          blockedAt: null,
          blockedReason: null,
        });
      }
    }

    // Quem tem o cargo da escala (`staff_panel_role_ids`, ex. 1566903220968624188)
    // é **escala fixa**; o resto é apoio (atendimentos aleatórios).
    // Cache de cargos indisponível → cai na regra "tem turno cadastrado?".
    const roster = this.staff.rosterIds ? this.staff.rosterIds(guildId) : null;

    const staff = [...staffRows.values()].map((row) => {
      const userShifts = shiftsByUser.get(row.userId) ?? [];
      const activeShift = findActiveShift(userShifts, now, this.timeZone);
      const activeSession = this.activeSession(guildId, row.userId);
      const next = findNextShift(userShifts, now, { timeZone: this.timeZone });
      const stats = reportByUser.get(row.userId);
      return {
        ...row,
        staffName:
          names.get(row.userId) ??
          row.staffName ??
          userShifts[0]?.staffName ??
          stats?.staffName ??
          null,
        shifts: userShifts.map((shift) => ({
          weekday: shift.weekday,
          weekdayLabel: shift.weekdayLabel,
          start: shift.start,
          end: shift.end,
          overnight: shift.overnight,
          parity: shift.parity ?? null,
        })),
        weekly: shiftsByWeekday(userShifts).map((day) => ({
          weekday: day.weekday,
          label: day.label,
          short: day.short,
          shifts: day.shifts.map((shift) => ({
            start: shift.start,
            end: shift.end,
            parity: shift.parity ?? null,
          })),
        })),
        currentShift: activeShift
          ? {
              start: minutesToHHMM(activeShift.shift.startMinutes),
              end: minutesToHHMM(activeShift.shift.endMinutes),
              startLabel: formatTime(new Date(activeShift.startTs), this.timeZone),
              endLabel: formatTime(new Date(activeShift.endTs), this.timeZone),
            }
          : null,
        nextShift: next
          ? {
              dayKey: next.dayKey,
              start: next.shift.start,
              end: next.shift.end,
              startTs: next.startTs,
              minutesAhead: Math.round((next.startTs - now) / 60000),
            }
          : null,
        session: activeSession
          ? {
              startedAt: activeSession.started_at,
              entry: formatTime(new Date(activeSession.started_at), this.timeZone),
              elapsedSeconds: activeSession.elapsedSeconds,
              lateMinutes: Number(activeSession.late_minutes) || 0,
            }
          : null,
        totals: {
          minutes: stats?.totalMinutes ?? 0,
          label: stats?.totalLabel ?? '0s',
          sessions: stats?.sessions ?? 0,
          lateMinutes: stats?.lateMinutes ?? 0,
          lateCount: stats?.lateCount ?? 0,
          earlyLeaveMinutes: stats?.earlyLeaveMinutes ?? 0,
          entryLabel: stats?.entryLabel ?? '—',
          exitLabel: stats?.exitLabel ?? '—',
        },
        // Grupo no painel web: escala fixa (cargo) ou apoio (atendimentos
        // aleatórios). `onRoster` fica null quando não dá para saber.
        onRoster: roster ? roster.has(row.userId) : null,
        hasSchedule: userShifts.length > 0,
        group:
          roster === null
            ? userShifts.length > 0
              ? 'ESCALA'
              : 'APOIO'
            : roster.has(row.userId)
              ? 'ESCALA'
              : 'APOIO',
      };
    });

    staff.sort((a, b) => Number(b.available) - Number(a.available) || b.totals.minutes - a.totals.minutes);

    // Quem estava escalado e não entrou em serviço no período (o painel web
    // mostra a lista e o resumo dos cartões).
    //
    // Só entra aqui quem **está na equipe agora**: os registros de quem foi
    // removido do quadro continuam no banco (auditoria/histórico), mas não
    // podem reaparecer na seção Presença nem nos cartões.
    const teamIds = new Set(staff.map((row) => row.userId));
    const absences = this.absences(guildId, {
      from: report.period.fromTs,
      to: now,
      now,
    }).filter((item) => teamIds.has(item.userId));
    const absencesSummary = {
      total: absences.length,
      missed: absences.filter((item) => item.status === 'FALTOU').length,
      late: absences.filter((item) => item.status === 'ATRASADO').length,
      showed: absences.filter((item) => item.status === 'ATRASOU').length,
      // Só atrasos contam minutos: quem faltou perdeu o turno inteiro, o que
      // distorceria o total (e o número já aparece em "faltas").
      lateMinutes: absences
        .filter((item) => item.status !== 'FALTOU')
        .reduce((sum, item) => sum + item.lateMinutes, 0),
    };

    return {
      generatedAt: now,
      period: report.period,
      totals: report.totals,
      absences,
      absencesSummary,
      // Grupo do revezamento nesta semana: quem tem escala 'A' só trabalha nas
      // semanas 'A' (as semanas alternam A/B).
      weekParity: weekParity(now, this.timeZone),
      staff,
    };
  }

  /**
   * Zera as horas do staff (ou de todos, sem `userId`).
   *
   * - Sessões encerradas são apagadas: o total do banco de horas volta a zero.
   * - A sessão aberta (staff em serviço agora) **não** é apagada: ela recomeça
   *   do zero a partir de agora, para o painel não mostrar horas de antes do
   *   reset em cima da sessão em andamento.
   *
   * Escala, nomes e avisos de turno não são afetados.
   */
  async resetHours({ guildId, userId = null, now = Date.now() } = {}) {
    const result = await this.db.transaction(async () => ({
      sessions: this.repo.deleteClosedSessionsSync(guildId, userId),
      restarted: this.repo.restartOpenSessionsSync(guildId, userId, now),
    }));
    logger.info(
      `[banco de horas] Horas zeradas ${userId ? `para ${userId}` : 'para toda a equipe'}: ` +
        `${result.sessions} sessão(ões) apagada(s), ${result.restarted} reiniciada(s).`,
    );
    return result;
  }

  /** Limpa sessões antigas do banco (manutenção opcional). */
  async purgeSessionsBefore(guildId, timestamp) {
    await this.db.transaction(async () =>
      this.db.run('DELETE FROM staff_sessions WHERE guild_id = ? AND ended_at IS NOT NULL AND ended_at < ?', [
        guildId,
        timestamp,
      ]),
    );
  }

  /** Último dia útil (para testes/relatórios): meia-noite local deslocada. */
  dayStart(offsetDays = 0, now = Date.now()) {
    return startOfDay(addDays(new Date(now), offsetDays), this.timeZone);
  }
}

module.exports = { HourBankService, parseDayStart, DEFAULT_REMINDER_MINUTES, DEFAULT_MAX_SESSION_HOURS };
