'use strict';

/**
 * Definição de todas as configurações editáveis em tempo de execução.
 * Nada aqui exige alterar código: os valores ficam no banco e podem ser
 * trocados pelo painel/ comandos administrativos.
 */
const { isValidSchedule, isValidHHMM } = require('../utils/validators');

const DEFAULT_SCHEDULE = {
  mon: [{ open: '12:00', close: '02:00' }],
  tue: [{ open: '12:00', close: '02:00' }],
  wed: [{ open: '12:00', close: '02:00' }],
  thu: [{ open: '12:00', close: '02:00' }],
  fri: [{ open: '12:00', close: '02:00' }],
  sat: [{ open: '12:00', close: '00:00' }],
  sun: [{ open: '12:00', close: '00:00' }],
};

const asBool = (value) => value === true || value === 'true' || value === 1 || value === '1';
const asInt = (min, max) => (value) => {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return null;
  if (parsed < min || parsed > max) return null;
  return parsed;
};
const asIdList = (value) => (Array.isArray(value) && value.every((v) => /^\d{17,20}$/.test(String(v))));
/** Número decimal (ex.: média de 0 a 4). */
const asDecimal = (min, max) => (value) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return null;
  if (parsed < min || parsed > max) return null;
  return Math.round(parsed * 100) / 100;
};

const SETTINGS = {
  guild_id: {
    default: null,
    type: 'string',
    label: 'ID do servidor',
    group: 'Identidade',
    validate: (v) => (v === null || /^\d{17,20}$/.test(String(v))),
  },
  public_channel_id: {
    default: null,
    type: 'string',
    label: 'Canal do painel público',
    group: 'Canais',
  },
  staff_channel_id: {
    default: null,
    type: 'string',
    label: 'Canal do painel da staff',
    group: 'Canais',
  },
  log_channel_id: {
    default: null,
    type: 'string',
    label: 'Canal de logs administrativos',
    group: 'Canais',
  },
  category_id: {
    default: null,
    type: 'string',
    label: 'Categoria 🎧・central de atendimento',
    group: 'Canais',
  },
  wait_channel_id: {
    default: null,
    type: 'string',
    label: 'Canal de voz ⏳・aguardando-atendimento',
    group: 'Canais',
  },
  attendance_channel_ids: {
    default: [],
    type: 'json',
    label: 'Canais de voz de atendimento',
    group: 'Canais',
    validate: asIdList,
  },
  staff_role_ids: {
    default: [],
    type: 'json',
    label: 'Cargos de staff',
    group: 'Permissões',
    validate: asIdList,
  },
  staff_panel_role_ids: {
    default: [],
    type: 'json',
    label: 'Cargos exibidos no painel da equipe (vazio = todos)',
    group: 'Permissões',
    validate: asIdList,
  },
  admin_role_ids: {
    default: [],
    type: 'json',
    label: 'Cargos administrativos',
    group: 'Permissões',
    validate: asIdList,
  },
  schedule: {
    default: DEFAULT_SCHEDULE,
    type: 'json',
    label: 'Horário de funcionamento',
    group: 'Funcionamento',
    validate: isValidSchedule,
  },
  central_manual: {
    default: 'auto',
    type: 'string',
    label: 'Estado manual da central (auto/open/closed)',
    group: 'Funcionamento',
    validate: (v) => ['auto', 'open', 'closed'].includes(v),
  },
  queue_policy_on_close: {
    default: 'keep',
    type: 'string',
    label: 'Fila ao fechar a central (keep/clear)',
    group: 'Funcionamento',
    validate: (v) => ['keep', 'clear'].includes(v),
  },
  max_queue_size: {
    default: 0,
    type: 'number',
    label: 'Tamanho máximo da fila (0 = ilimitado)',
    group: 'Fila',
    validate: asInt(0, 500),
  },
  wait_alert_minutes: {
    default: 3,
    type: 'number',
    label: 'Avisar a equipe por DM quando alguém esperar mais de X minutos (0 = desativado)',
    group: 'Fila',
    validate: asInt(0, 120),
  },
  max_wait_minutes: {
    default: 0,
    type: 'number',
    label: 'Tempo limite de espera em minutos (0 = sem limite)',
    group: 'Fila',
    validate: asInt(0, 600),
  },
  auto_queue_on_voice_join: {
    default: true,
    type: 'boolean',
    label: 'Entrar na fila ao entrar no canal de espera',
    group: 'Fila',
    validate: asBool,
  },
  skip_policy: {
    default: 'end',
    type: 'string',
    label: 'Política de jogador pulado (end/hold)',
    group: 'Fila',
    validate: (v) => ['end', 'hold'].includes(v),
  },
  presence_timeout_minutes: {
    default: 5,
    type: 'number',
    label: 'Tempo para o jogador comparecer (min)',
    group: 'Atendimento',
    validate: asInt(1, 60),
  },
  no_show_policy: {
    default: 'requeue',
    type: 'string',
    label: 'Jogador não compareceu (requeue/close)',
    group: 'Atendimento',
    validate: (v) => ['requeue', 'close'].includes(v),
  },
  voice_disconnect_grace_seconds: {
    default: 120,
    type: 'number',
    label: 'Tolerância de desconexão de voz (s)',
    group: 'Atendimento',
    validate: asInt(30, 1800),
  },
  allow_staff_multi: {
    default: false,
    type: 'boolean',
    label: 'Permitir staff em múltiplos atendimentos',
    group: 'Atendimento',
    validate: asBool,
  },
  staff_auto_status_on_voice_join: {
    default: false,
    type: 'boolean',
    label: 'Staff entra em serviço ao entrar no canal de atendimento',
    group: 'Atendimento',
    validate: asBool,
  },
  staff_auto_available: {
    default: true,
    type: 'boolean',
    label: 'Staff volta a DISPONÍVEL ao finalizar',
    group: 'Atendimento',
    validate: asBool,
  },
  notifications_position_change: {
    default: true,
    type: 'boolean',
    label: 'Avisar jogador quando a posição mudar',
    group: 'Notificações',
    validate: asBool,
  },
  position_notify_cooldown_minutes: {
    default: 10,
    type: 'number',
    label: 'Intervalo mínimo entre avisos de posição (min)',
    group: 'Notificações',
    validate: asInt(1, 240),
  },
  evaluations_enabled: {
    default: true,
    type: 'boolean',
    label: 'Enviar avaliação após o atendimento',
    group: 'Avaliações',
    validate: asBool,
  },
  evaluation_channel_id: {
    default: null,
    type: 'string',
    label: 'Canal onde as avaliações são publicadas',
    group: 'Avaliações',
    validate: (value) => value === null || value === undefined || value === '' || /^\d{5,25}$/.test(String(value).trim()),
  },
  evaluations_alert_min_average: {
    default: 0,
    type: 'decimal',
    label: 'Avisar no canal quando a média da semana ficar abaixo de (0 = desligado)',
    group: 'Avaliações',
    validate: asDecimal(0, 4),
  },
  evaluations_alert_min_sample: {
    default: 3,
    type: 'number',
    label: 'Mínimo de avaliações na semana para o aviso',
    group: 'Avaliações',
    validate: asInt(1, 200),
  },
  evaluations_alert_last_week: {
    default: null,
    type: 'string',
    label: 'Semana do último aviso de avaliações (interno)',
    group: 'Avaliações',
    validate: (value) => value === null || value === undefined || value === '' || /^\d{4}-\d{2}-\d{2}$/.test(String(value)),
  },
  panel_style: {
    default: 'modern',
    type: 'string',
    label: 'Estilo do painel público (modern/classic)',
    group: 'Painéis',
    validate: (v) => ['modern', 'classic'].includes(v),
  },
  panel_refresh_seconds: {
    default: 30,
    type: 'number',
    label: 'Atualização automática dos painéis (s)',
    group: 'Painéis',
    validate: asInt(10, 600),
  },
  average_wait_window_minutes: {
    default: 120,
    type: 'number',
    label: 'Janela para calcular espera média (min)',
    group: 'Painéis',
    validate: asInt(15, 1440),
  },
  stats_ranking_min_sample: {
    default: 3,
    type: 'number',
    label: 'Atendimentos mínimos para entrar no ranking',
    group: 'Relatórios',
    validate: asInt(1, 100),
  },
  message_panel_title: {
    default: '🎧 ATENDIMENTO | VANTUS',
    type: 'string',
    label: 'Título do painel público',
    group: 'Mensagens',
    validate: (v) => typeof v === 'string' && v.length > 0 && v.length <= 120,
  },
  hour_bank_enabled: {
    default: true,
    type: 'boolean',
    label: 'Contar horas do staff em serviço (banco de horas)',
    group: 'Banco de horas',
    validate: asBool,
  },
  hour_bank_reminder_minutes: {
    default: 5,
    type: 'number',
    label: 'Aviso por DM (minutos antes do turno; 0 desliga)',
    group: 'Banco de horas',
    validate: asInt(0, 120),
  },
  hour_bank_max_session_hours: {
    default: 12,
    type: 'number',
    label: 'Fechamento automático de sessões longas (horas)',
    group: 'Banco de horas',
    validate: asInt(1, 48),
  },
  hour_bank_absence_minutes: {
    default: 10,
    type: 'number',
    label: 'Tolerância antes de registrar falta/atraso do turno (min; 0 desliga)',
    group: 'Banco de horas',
    validate: asInt(0, 240),
  },
  hour_bank_absence_catchup_hours: {
    default: 12,
    type: 'number',
    label: 'Janela para registrar turnos perdidos com o bot offline (horas)',
    group: 'Banco de horas',
    validate: asInt(0, 72),
  },
  hour_bank_absence_role_ids: {
    default: ['1560793864330158240', '1566903222088499251'],
    type: 'json',
    label: 'Cargos avisados quando um staff não entra em serviço',
    group: 'Banco de horas',
    validate: asIdList,
  },
  hour_bank_absence_channel_id: {
    // Canal de log de atendimento: o aviso de falta não é para a equipe ver no
    // painel da staff, é registro administrativo.
    default: '1566903219915858102',
    type: 'string',
    label: 'Canal do aviso de não entrada em serviço (vazio = canal de logs)',
    group: 'Banco de horas',
    validate: (v) => v === null || v === undefined || v === '' || /^\d{17,20}$/.test(String(v)),
  },
  hour_bank_webhook_url: {
    default: null,
    type: 'string',
    label: 'Webhook que recebe a escala da semana (vazio desliga)',
    group: 'Banco de horas',
    // A validação completa (formato do webhook do Discord) fica no painel/módulo de envio.
    validate: (v) => v === null || v === undefined || (typeof v === 'string' && v.length <= 400),
  },
  hour_bank_webhook_auto: {
    default: false,
    type: 'boolean',
    label: 'Enviar a escala da semana automaticamente',
    group: 'Banco de horas',
    validate: asBool,
  },
  hour_bank_webhook_day: {
    default: 1,
    type: 'number',
    label: 'Dia do envio automático (0 = domingo … 6 = sábado)',
    group: 'Banco de horas',
    validate: asInt(0, 6),
  },
  hour_bank_webhook_time: {
    default: '09:00',
    type: 'string',
    label: 'Horário do envio automático (HH:MM)',
    group: 'Banco de horas',
    validate: (v) => typeof v === 'string' && /^([01]?\d|2[0-3]):[0-5]\d$/.test(v.trim()),
  },
  hour_bank_webhook_last_week: {
    default: null,
    type: 'string',
    label: 'Última semana publicada no webhook (controle interno)',
    group: 'Banco de horas',
    validate: (v) => v === null || v === undefined || /^\d{4}-\d{2}-\d{2}$/.test(String(v)),
  },
  message_closed: {
    default: 'A central de atendimento está fechada no momento. Confira os horários de funcionamento abaixo.',
    type: 'string',
    label: 'Mensagem de central fechada',
    group: 'Mensagens',
    validate: (v) => typeof v === 'string' && v.length > 0 && v.length <= 500,
  },
  // ---------------------------------------------------------------- //
  // Push no celular do dono quando alguém entra na fila (ntfy)        //
  // ---------------------------------------------------------------- //
  push_enabled: {
    default: false,
    type: 'boolean',
    label: 'Avisar no celular quando alguém entrar na fila',
    group: 'Notificações',
    validate: asBool,
  },
  push_endpoint: {
    default: 'https://ntfy.sh',
    type: 'string',
    label: 'Servidor de notificação',
    group: 'Notificações',
    validate: (v) => typeof v === 'string' && v.length <= 300,
  },
  push_topic: {
    default: '',
    type: 'string',
    label: 'Tópico do ntfy',
    group: 'Notificações',
    // Letras, números, "-" e "_" — o tópico funciona como senha do aviso.
    validate: (v) => typeof v === 'string' && (v === '' || /^[A-Za-z0-9_-]{3,64}$/.test(v)),
  },
  push_token: {
    default: '',
    type: 'string',
    label: 'Token de acesso do ntfy',
    group: 'Notificações',
    validate: (v) => typeof v === 'string' && v.length <= 200,
  },
  push_on_queue_join: {
    default: true,
    type: 'boolean',
    label: 'Avisar entrada na fila',
    group: 'Notificações',
    validate: asBool,
  },
  push_on_queue_blocked: {
    default: true,
    type: 'boolean',
    label: 'Avisar tentativa de entrada com a central fechada',
    group: 'Notificações',
    validate: asBool,
  },
  push_last_status: {
    default: '',
    type: 'string',
    label: 'Último envio (status)',
    group: 'Notificações',
    validate: (v) => typeof v === 'string' && v.length <= 300,
  },
  push_last_error: {
    default: '',
    type: 'string',
    label: 'Último envio (erro)',
    group: 'Notificações',
    validate: (v) => typeof v === 'string' && v.length <= 300,
  },
  push_last_at: {
    default: 0,
    type: 'number',
    label: 'Último envio (data)',
    group: 'Notificações',
    validate: (v) => Number.isFinite(Number(v)),
  },
};

const VALID_GROUPS = [...new Set(Object.values(SETTINGS).map((def) => def.group))];

/** Converte valor bruto (texto do banco/entrada) para o tipo do setting. */
function coerceValue(key, raw) {
  const def = SETTINGS[key];
  if (!def) return { ok: false, error: `Configuração "${key}" não existe.` };

  let value = raw;
  if (def.type === 'json' && typeof raw === 'string') {
    try {
      value = JSON.parse(raw);
    } catch {
      return { ok: false, error: 'Valor JSON inválido.' };
    }
  }
  if (def.type === 'number' && typeof raw === 'string') value = Number.parseInt(raw, 10);
  if (def.type === 'decimal' && typeof raw === 'string') value = Number.parseFloat(raw.replace(',', '.'));
  if (def.type === 'boolean' && typeof raw === 'string') value = asBool(raw);

  if (def.validate && !def.validate(value)) {
    return { ok: false, error: `Valor inválido para ${def.label}.` };
  }
  return { ok: true, value };
}

/** Serializa para o banco (sempre JSON, preservando o tipo). */
function serializeValue(value) {
  return JSON.stringify(value === undefined ? null : value);
}

function deserializeValue(raw, fallback) {
  if (raw === null || raw === undefined) return fallback;
  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

/** Conjunto de defaults para popular o banco na primeira execução. */
function defaultSettings() {
  const result = {};
  for (const [key, def] of Object.entries(SETTINGS)) result[key] = def.default;
  return result;
}

module.exports = {
  SETTINGS,
  VALID_GROUPS,
  DEFAULT_SCHEDULE,
  coerceValue,
  serializeValue,
  deserializeValue,
  defaultSettings,
  isValidHHMM,
};
