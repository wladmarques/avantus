'use strict';

/**
 * Pré-visualização local do painel web do banco de horas.
 *   npm run preview:web
 *
 * Sobe o painel com um banco temporário e dados de exemplo (staff, escalas e
 * sessões dos últimos dias) — nenhum dado do seu servidor é usado.
 * Senha padrão: vantus (defina PREVIEW_PASSWORD para trocar).
 */
const fs = require('node:fs');
const path = require('node:path');
const { openDatabase } = require('../src/database/connection');
const { runMigrations } = require('../src/database/migrations');
const { createServices } = require('../src/services');
const { MemoryGateway } = require('../src/services/discordGateway');
const { startWebServer } = require('../src/web/server');
const { createLogger, setLevel } = require('../src/utils/logger');
const { startOfDay, tzParts, dayKey } = require('../src/utils/time');

// LOG_LEVEL=debug mostra cada requisição do painel no console.
setLevel(process.env.LOG_LEVEL || 'warn');
const logger = createLogger('preview-web');

const root = path.join(__dirname, '..');
const dbFile = path.join(root, 'data', 'preview-web.sqlite');
const PORT = Number(process.env.WEB_PANEL_PORT) || 8080;
const PASSWORD = process.env.PREVIEW_PASSWORD || 'vantus';
const GUILD = '100000000000000001';
const MINUTE = 60000;

// Revezamento: o grupo A trabalha um fim de semana e o B no seguinte.
const STAFF = [
  { id: '900000000000000001', name: 'pedrosa17', status: 'DISPONIVEL', weekday: ['12:00', '02:00'], weekend: 'A' },
  { id: '900000000000000002', name: 'gabriel_tt', status: 'EM_ATENDIMENTO', weekday: ['12:00', '02:00'], weekend: 'A' },
  { id: '900000000000000003', name: 'lucas.v', status: 'AUSENTE', weekday: ['20:00', '02:00'], weekend: 'B' },
  { id: '900000000000000004', name: 'mika', status: 'INDISPONIVEL', weekday: ['12:00', '02:00'], weekend: 'B' },
];

// Staff sem nome cadastrado: o painel mostra "Usuário <id>" até alguém definir o
// nome (botão "Definir nome") — ou até o nome ser resolvido pelo Discord.
const SEM_NOME = '271052015704997888';

// Cargo de escala no Discord: quem tem esse cargo é "escala fixa" na tabela do
// painel web; quem não tem aparece no grupo "apoio" (atendimentos aleatórios).
const ROSTER_ROLE = '1566903220968624188';

function hhmm(minutes) {
  const value = ((minutes % 1440) + 1440) % 1440;
  return `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(value % 60).padStart(2, '0')}`;
}

async function main() {
  fs.mkdirSync(path.dirname(dbFile), { recursive: true });
  for (const suffix of ['', '.bak', '.tmp']) fs.rmSync(`${dbFile}${suffix}`, { force: true });

  const db = await openDatabase({ filePath: dbFile });
  await runMigrations(db);
  const gateway = new MemoryGateway({ settings: null });
  const services = await createServices({ db, gateway });
  gateway.settings = services.settings;

  await services.settings.setMany({
    guild_id: GUILD,
    central_manual: 'open',
    wait_channel_id: '200000000000000001',
  });

  // Teste local do webhook da escala: aponte para um receptor seu, por exemplo
  //   PREVIEW_WEBHOOK_URL=http://127.0.0.1:8099/hook npm run preview:web
  if (process.env.PREVIEW_WEBHOOK_URL) {
    await services.settings.set('hour_bank_webhook_url', process.env.PREVIEW_WEBHOOK_URL);
  }

  // Silencia o log enquanto os dados de exemplo são criados.
  const desiredLevel = process.env.LOG_LEVEL || 'warn';
  setLevel('warn');

  // Escala de exemplo: dias úteis com o mesmo horário + fim de semana revezado.
  const scheduleShifts = ({ weekday: weekdayTimes, weekend }) => {
    const [start, end] = weekdayTimes;
    const shifts = [1, 2, 3, 4, 5].map((weekday) => ({ weekday, start, end }));
    for (const weekday of [6, 0]) {
      shifts.push({ weekday, start, end, parity: weekend });
    }
    return shifts;
  };

  for (const [index, staff] of STAFF.entries()) {
    await services.hourBank.setSchedule({
      guildId: GUILD,
      userId: staff.id,
      staffName: staff.name,
      shifts: scheduleShifts(staff),
    });

    // Sessões dos últimos dias (entrada alguns minutos após o turno → atraso).
    for (const day of [3, 2, 1]) {
      const dayTs = startOfDay(new Date(Date.now() - day * 24 * 60 * MINUTE));
      const started = dayTs + (12 * 60 + 5 + index * 4) * MINUTE;
      await services.hourBank.startSession({
        guildId: GUILD,
        userId: staff.id,
        staffName: staff.name,
        at: started,
      });
      await services.hourBank.endSession({
        guildId: GUILD,
        userId: staff.id,
        at: started + (240 - index * 35) * MINUTE,
      });
    }
  }

  // Status depois das sessões históricas: pedrosa17 fica em serviço agora.
  for (const staff of STAFF) {
    await services.staff.setStatus({
      guildId: GUILD,
      userId: staff.id,
      status: staff.status,
      updatedBy: 'preview',
      manual: true,
    });
  }

  /* ---------------- Não entrada em serviço (faltas e atrasos) ---------------- */

  // Um staff escalado para hoje que ainda não entrou em serviço: é o mesmo
  // caminho do bot real (o watcher registra depois da tolerância).
  const nowParts = tzParts(new Date());
  const startedMinutesAgo = nowParts.hour * 60 + nowParts.minute - 90;
  const ATUAL = '900000000000000007';
  gateway.members.set(ATUAL, { inGuild: true, displayName: 'sem.comparecer', staffRoles: [ROSTER_ROLE] });
  await services.hourBank.setSchedule({
    guildId: GUILD,
    userId: ATUAL,
    staffName: 'sem.comparecer',
    shifts: [
      {
        weekday: nowParts.weekday,
        start: hhmm(startedMinutesAgo),
        end: hhmm(startedMinutesAgo + 240),
      },
    ],
  });
  {
    const shift = services.hourBank.listShifts(GUILD, ATUAL)[0];
    const startTs = startOfDay(new Date()) + shift.startMinutes * MINUTE;
    await services.hourBank.repo.openAbsenceSync(GUILD, ATUAL, {
      staffName: 'sem.comparecer',
      shiftId: shift.shiftId,
      shiftDay: dayKey(new Date()),
      scheduledStart: startTs,
      scheduledEnd: startTs + shift.durationMinutes * MINUTE,
      detectedAt: startTs + 10 * MINUTE,
    });
  }

  /** Registro histórico de ausência no turno do staff para o dia deslocado. */
  const seedAbsence = async ({ staff, daysAgo, returnedAfter = null }) => {
    const day = new Date(Date.now() - daysAgo * 24 * 60 * MINUTE);
    const weekday = tzParts(day).weekday;
    const shift = services.hourBank
      .listShifts(GUILD, staff.id)
      .find((item) => item.weekday === weekday);
    if (!shift) return;
    const startTs = startOfDay(day) + shift.startMinutes * MINUTE;
    const endTs = startOfDay(day) + (shift.startMinutes + shift.durationMinutes) * MINUTE;
    const row = await services.hourBank.repo.openAbsenceSync(GUILD, staff.id, {
      staffName: staff.name,
      shiftId: shift.shiftId,
      shiftDay: dayKey(day),
      scheduledStart: startTs,
      scheduledEnd: endTs,
      detectedAt: startTs + 10 * MINUTE,
    });
    await services.hourBank.repo.markAbsenceNotifiedSync(row.id, startTs + 10 * MINUTE);
    if (returnedAfter !== null) {
      await services.hourBank.repo.markAbsenceReturnedSync(GUILD, staff.id, {
        returnedAt: startTs + returnedAfter * MINUTE,
        lateMinutes: returnedAfter,
      });
    }
  };

  // Faltou o turno inteiro / chegou 25 min depois.
  await seedAbsence({ staff: STAFF[2], daysAgo: 1 });
  await seedAbsence({ staff: STAFF[3], daysAgo: 2, returnedAfter: 25 });

  // Cargo da escala nos 4 staff com horário fixo (grupo "escala fixa").
  await services.settings.set('staff_panel_role_ids', [ROSTER_ROLE]);
  for (const staff of STAFF) {
    gateway.members.set(staff.id, {
      inGuild: true,
      displayName: staff.name,
      staffRoles: [ROSTER_ROLE],
    });
  }

  // Staff com o cargo que NUNCA entrou em serviço: antes sumia do painel web
  // (não tinha linha em staff_status). Aparece em "Escala fixa" com "sem escala".
  gateway.members.set('900000000000000006', {
    inGuild: true,
    displayName: 'escala.sem-status',
    staffRoles: [ROSTER_ROLE],
  });

  // Exemplo de nome resolvido automaticamente pelo Discord (membro do servidor).
  // Este NÃO tem o cargo: entra no grupo "apoio", com atendimentos aleatórios.
  gateway.members.set('900000000000000005', {
    inGuild: true,
    displayName: 'renan.br',
    staffRoles: ['900000000000000777'],
  });
  await services.staff.setStatus({
    guildId: GUILD,
    userId: '900000000000000005',
    status: 'DISPONIVEL',
    updatedBy: 'preview',
    manual: true,
  });

  // Exemplo do caso sem nome nenhum (nem no painel, nem no Discord).
  gateway.members.set(SEM_NOME, {
    inGuild: true,
    displayName: 'apoio.sem-nome',
    staffRoles: ['900000000000000777'],
  });
  await services.staff.setStatus({
    guildId: GUILD,
    userId: SEM_NOME,
    status: 'AUSENTE',
    updatedBy: 'preview',
    manual: true,
  });
  await services.hourBank.startSession({
    guildId: GUILD,
    userId: SEM_NOME,
    at: Date.now() - 70 * MINUTE,
  });
  await services.hourBank.endSession({ guildId: GUILD, userId: SEM_NOME, at: Date.now() - 20 * MINUTE });

  // Avaliações de exemplo (o painel mostra média, distribuição e ranking).
  const SAMPLE_EVALUATIONS = [
    { protocol: 101, userId: '700000000000000101', username: 'jogador.alfa', staff: 0, rating: 'MUITO_BOM', daysAgo: 1 },
    { protocol: 102, userId: '700000000000000102', username: 'jogador.beta', staff: 0, rating: 'BOM', daysAgo: 2 },
    { protocol: 103, userId: '700000000000000103', username: 'jogador.gama', staff: 1, rating: 'REGULAR', daysAgo: 3 },
    { protocol: 104, userId: '700000000000000104', username: 'jogador.delta', staff: 2, rating: 'RUIM', daysAgo: 4 },
    { protocol: 105, userId: '700000000000000105', username: 'jogador.epsilon', staff: 1, rating: 'MUITO_BOM', daysAgo: 5 },
  ];
  for (const sample of SAMPLE_EVALUATIONS) {
    const staff = STAFF[sample.staff];
    const at = Date.now() - sample.daysAgo * 24 * 60 * MINUTE;
    const attendance = services.repositories.attendance.createSync({
      guildId: GUILD,
      protocol: sample.protocol,
      userId: sample.userId,
      username: sample.username,
      status: 'finished',
      joinedAt: at - 30 * MINUTE,
      queueSeq: sample.protocol,
      staffId: staff.id,
      staffTag: staff.name,
    });
    db.run('UPDATE attendance SET outcome = ?, duration_seconds = ? WHERE id = ?', [
      'CONCLUIDO',
      (18 + sample.rating.length * 3) * 60,
      attendance.id,
    ]);
    services.repositories.evaluations.createSync({
      guildId: GUILD,
      attendanceId: attendance.id,
      protocol: attendance.protocol,
      userId: sample.userId,
      staffId: staff.id,
      staffTag: staff.name,
      rating: sample.rating,
    });
    db.run('UPDATE evaluations SET created_at = ? WHERE attendance_id = ?', [at, attendance.id]);
  }
  await services.settings.set('evaluation_channel_id', '1560793933750210582');

  // Aviso no celular: já vem preenchido no preview, mas **desligado** — nada é
  // enviado para o ntfy.sh enquanto você não ligar e clicar em Enviar teste.
  await services.settings.setMany({
    push_endpoint: 'https://ntfy.sh',
    push_topic: 'vantus-fila-preview-8j3k9m2x',
    push_enabled: false,
  });

  const active = services.hourBank.activeSession(GUILD, STAFF[0].id);
  if (active) {
    db.run('UPDATE staff_sessions SET started_at = ?, late_minutes = ? WHERE id = ?', [
      Date.now() - 95 * MINUTE,
      12,
      active.id,
    ]);
  }

  setLevel(desiredLevel);

  const web = await startWebServer({
    services,
    env: { webPanelPassword: PASSWORD, webPanelPort: PORT, timezone: 'America/Sao_Paulo', guildId: GUILD },
    logger: {
      info: (message) => console.log(`✔ ${message}`),
      debug: () => {},
      warn: (message) => console.log(`⚠ ${message}`),
      error: (message) => console.log(`✖ ${message}`),
    },
  });

  if (!web) {
    console.error('Não foi possível iniciar o painel.');
    process.exit(1);
  }

  // Mesmo watcher do bot: se o envio automático estiver ligado, publica a escala.
  services.scheduleBroadcast.startWatcher(GUILD);

  console.log('');
  console.log(`   Painel: http://localhost:${web.port}`);
  console.log(`   Senha:  ${PASSWORD}`);
  console.log(`   Banco:  ${path.relative(root, dbFile)} (apague para resetar)`);
  console.log('');
}

main().catch((error) => {
  logger.error('Falha na pré-visualização', error);
  process.exit(1);
});
