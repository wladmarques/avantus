# Banco de horas da equipe

Controle de jornada dos staffs: escala semanal, contagem automática das horas em serviço,
aviso por DM antes do turno e relatórios completos em um painel web.

## Como funciona

| Momento | O que acontece |
| --- | --- |
| O staff se coloca **DISPONÍVEL** (`/status` ou **MEU STATUS** no painel da equipe) | a sessão de trabalho **abre** e as horas começam a contar |
| O staff entra **EM ATENDIMENTO** | a sessão **continua** aberta (ele segue em serviço) |
| O staff fica **AUSENTE / INDISPONÍVEL** ou sai do canal | a sessão **fecha** e as horas são gravadas |
| O staff só **entra no canal de atendimento** (sem mudar o status) | nada acontece: ele continua fora de serviço, sem horas contando e sem poder chamar jogador |
| Faltam **5 minutos** para o turno cadastrado | o bot envia uma **DM de aviso** (uma única vez por turno/dia) |
| A sessão passa de `hour_bank_max_session_hours` (padrão 12h) | é fechada automaticamente (proteção contra queda do bot) |
| Passam `hour_bank_absence_minutes` (padrão 10) do início do turno **sem ninguém em serviço** | o bot **registra a não entrada em serviço** e avisa os cargos da administração no canal de logs |
| O staff aparece depois, ainda dentro do turno | o registro passa a **"atrasou X"** (o atraso fica no histórico) |
| O turno termina sem o staff | o registro fica como **"faltou"** |

**Atraso** = diferença entre a entrada real e o início do turno cadastrado (nos fins de semana
revezados, só conta para quem está escalado naquele fim de semana).
**Saída antecipada** = diferença entre o fim do turno e a saída real.

Nada disso é manual: os números vêm do próprio status do staff, que já é atualizado
automaticamente pelo painel, pelos comandos e pelos eventos de voz.

## Painel web

O painel é servido pelo **mesmo processo do bot** (Node HTTP nativo, sem dependências novas).

### Configuração

```bash
# .env
WEB_PANEL_PASSWORD=uma-senha-forte      # obrigatória: sem ela o painel fica desligado
WEB_PANEL_PORT=8080                     # SquareCloud (site): use 80
WEB_PANEL_HOST=0.0.0.0
```

- **Local:** `http://localhost:8080` → senha → pronto.
- **SquareCloud:** o painel só é acessível pela internet se o app estiver configurado como
  **Site** (a SquareCloud expõe a porta 80). Nesse caso use `WEB_PANEL_PORT=80`.
  Se preferir apenas o bot, deixe `WEB_PANEL_PASSWORD` vazio — o painel não sobe e o bot
  funciona normalmente.

### O que aparece

O painel abre em **Visão geral** e o menu lateral (recolhível) leva às seções: Visão geral,
Equipe, Presença, Central, Avaliações, Escala e Notificações.

- **Cartões**: staff cadastrados, quem está em serviço agora, horas no período e atrasos.
- **Gestão da equipe** (na Visão geral): quem está em serviço aparece primeiro, com status,
  turno de hoje e horas do período; um clique abre as sessões da pessoa.
- **Presença** (seção própria): cartões de *faltas no período*, *em atraso agora*, *chegaram
  atrasados* e *minutos de atraso*, mais a tabela **Não entrada em serviço** com dia, staff,
  turno, situação (`faltou` / `em atraso` / `compareceu`) e a hora em que o bot registrou.
- **Tabela da equipe** (elemento principal da gestão): nome e ID, status com indicador colorido
  — **verde** em serviço, **cinza** indisponível, **vermelho** bloqueado, **laranja** atenção —,
  turno de hoje, entrada, saída, horas do período, atrasos acumulados e o **menu de ações**.
  Acima da tabela há **busca por nome/ID** e o filtro **Todos / Em serviço / Com atraso /
  Bloqueados**, com a contagem de funcionários à direita. A tabela separa **Escala fixa**
  (cargo `1566903220968624188`) de **Apoio**, e cada grupo pode ser recolhido pelo cabeçalho.
- **Avaliações**: média das notas (0–4), total no período, % de notas boas, distribuição em
  barras, tabela com data/jogador/atendente/nota/protocolo e a média por atendente. Há um campo
  para definir o **canal do Discord** que recebe cada avaliação (ou use `EVALUATION_CHANNEL_ID`
  / `/config definir`). O seletor **Atendente** filtra as notas de uma pessoa (o ranking continua
  completo) e **CSV das avaliações** baixa o período com data, protocolo, jogador, atendente, nota
  e duração. Há também o campo de **alerta**: quando a média dos últimos 7 dias fica abaixo do
  limite (0 = desligado), o bot publica um aviso no canal de avaliações — no máximo uma vez por
  semana e só com pelo menos 3 notas no período.
- **Escala cadastrada**: resumo semanal de cada staff.
- **Sessões** (clique na linha): cada entrada/saída do período, com etiqueta de
  *EM SERVIÇO*, *ATRASO n min* ou *NO HORÁRIO*.
- **Período**: hoje, 7 dias, 30 dias ou intervalo personalizado.
- **CSV**: exporta o relatório do período (horas, sessões, entrada, saída, atrasos).
### Ações administrativas

Cada linha tem um único botão **⋮** (menu de três pontos) — nada de vários botões na linha.
O menu reúne, sem mudar o comportamento de antes:

- **Alterar nome**: define o nome exibido nos painéis (o nome do Discord continua como
  sugestão em *Usar nome do Discord*).
- **Editar escala**: dias úteis (mesmo horário), fim de semana e revezamento A/B.
- **Tirar de serviço**: aparece só para quem está em serviço.
- **Zerar horas**: apaga o histórico de horas daquele staff.
- **Bloquear / Desbloquear**: impede (ou libera) a entrada em serviço.
- **Remover**: tira o staff da equipe do banco de horas.

O **Tirar de serviço** encerra a sessão do banco de horas agora, marca o staff como
**INDISPONÍVEL** e, se estiver no canal de voz de trabalho, desconecta da call — útil quando
alguém esquece de sair e as horas continuam contando. O staff recebe uma DM explicando como
voltar (`/status`). Se ele estiver atendendo um jogador, a ação é **recusada** (o atendimento
precisa ser encerrado/transferido no Discord antes, para o jogador não ficar órfão).

### Zerar horas

Cada linha da tabela **Equipe** tem a ação **Zerar horas** no menu ⋮, e o cabeçalho da seção
**Equipe** tem **Zerar horas de todos**. Pede confirmação num modal e:

- apaga as **sessões encerradas** do staff (ou de todos) — o total do banco de horas volta a zero;
- **não** apaga a sessão aberta de quem está em serviço agora: ela recomeça a contar a partir do
  momento do reset (o staff continua em serviço, sem horas antigas em cima);
- **não** mexe em escala, nome, status nem bloqueio;
- registra `HOURS_RESET` na auditoria (canal de logs), dizendo quem zerou e quantas sessões saíram.

Use quando a contagem sair do controle (sessão esquecida aberta, teste, virada de período). Não há
como desfazer — o histórico apagado não volta.

### Escala no canal (webhook)

O painel publica a **escala da semana** (segunda a domingo) no canal do webhook informado.

1. No Discord: canal → **Editar canal** → **Integrações** → **Webhooks** → **Novo webhook** →
   **Copiar URL do webhook**.
2. No painel, em **Escala no canal**, cole a URL e clique em **Salvar**.
3. Clique em **Enviar escala agora** — a mensagem é publicada na hora.

Como a mensagem é montada (sem emojis, paleta VANTUS):

```
ESCALA DA SEMANA
26/10 a 01/11 · fim de semana A
Horários no fuso do bot. Turnos com "+1 dia" terminam no dia seguinte.

Segunda a sexta · 26/10–30/10
Conde — 11:00–15:00
Rafael Kavallieri 0303 — 11:00–15:00

Sábado e domingo · 31/10 e 01/11
Conde — 11:00–13:00
VANTUS • Banco de horas
```

- embed com barra vermelha `#ff2200` e título `ESCALA DA SEMANA`;
- a descrição mostra a semana e o **grupo do fim de semana** (`· fim de semana A`);
- **dias com a mesma escala viram um bloco só** — como os dias úteis são idênticos, a semana
  inteira costuma caber em duas seções (`Segunda a sexta · 26/10–30/10` e
  `Sábado e domingo · 31/10 e 01/11`) em vez de sete colunas repetidas;
- cada staff aparece **uma vez por bloco**, com os turnos encadeados resumidos:
  `11:00–13:00` + `13:00–15:00` → `11:00–15:00`;
- campos em largura cheia (nada de três colunas apertadas quebrando o nome);
- staffs ordenados pelo horário de início (e pelo nome em caso de empate);
- nos fins de semana só entram os staffs do **grupo daquela semana**;
- dias sem ninguém escalado não aparecem; semana vazia mostra *Ninguém escalado nesta semana.*;
- ninguém é mencionado/pingado (`allowed_mentions.parse` vazio).

O webhook fica salvo na configuração `hour_bank_webhook_url` (tabela `settings`) e só é
aceito no formato do Discord — para remover, apague o campo e salve (isso também desliga o
envio automático).

#### Envio automático

No mesmo painel, marque **Enviar automaticamente**, escolha o **dia da semana** e o **horário**
e clique em **Salvar**. Regras:

- o envio acontece **uma vez por semana**, no dia/horário escolhidos (padrão: segunda, 09:00);
- se o bot estiver desligado na hora exata, a escala é publicada **assim que ele voltar no
  mesmo dia** (não fica esperando a semana seguinte);
- reiniciar o bot **não duplica** a mensagem: a semana publicada fica gravada em
  `hour_bank_webhook_last_week`;
- **Enviar escala agora** também marca a semana como publicada — o automático não repete;
- se o webhook recusar a mensagem, a semana **não** é marcada e o bot tenta de novo a cada
  minuto (o erro aparece no log `hourbank`).

Configurações relacionadas (também editáveis por `/config`):

| Chave | Padrão | Para que serve |
| --- | --- | --- |
| `hour_bank_webhook_url` | *(vazio)* | URL do webhook do canal |
| `hour_bank_webhook_auto` | `false` | liga o envio automático |
| `hour_bank_webhook_day` | `1` | dia do envio (0 = domingo … 6 = sábado) |
| `hour_bank_webhook_time` | `09:00` | horário do envio (HH:MM) |
| `hour_bank_webhook_last_week` | — | última semana publicada (controle interno) |

> Para testar sem postar em um canal real, rode o receptor local e suba o preview apontando
> para ele: `node scripts/dev-webhook-sink.js` em um terminal e, no outro,
> `PREVIEW_WEBHOOK_URL=http://127.0.0.1:8099/hook npm run preview:web`.

### Nome do staff

Cada staff aparece pelo **nome cadastrado**. A ordem usada pelo painel é:

1. nome definido manualmente no painel (**Nome** / **Definir nome** na linha do staff);
2. nome guardado de uma resolução anterior;
3. nome do membro no servidor (resolvido automaticamente pela API do Discord);
4. nome que ficou registrado na escala ou nas sessões;
5. se nada existir: `Usuário <id>`.

O botão **Usar nome do Discord** remove o nome manual e deixa o painel voltar a usar o nome do
membro. O nome manual **nunca** é sobrescrito pela resolução automática. Tudo fica na tabela
`staff_names` (migração v6), então sobrevive a reinícios.

> O nome do Discord é resolvido no primeiro carregamento do painel e guardado — se o bot estiver
> offline (sem conexão com o Discord), o painel mantém o último nome conhecido.

### Cadastrar a escala

A escala tem **dois blocos** — não é preciso cadastrar dia por dia.

1. Clique em **Editar escala** na linha do staff.
2. **Dias úteis**: marque a caixa e informe **um único horário** — ele vale de segunda a sexta.
3. **Fim de semana**: marque a caixa, informe o horário e escolha o **revezamento**:
   - **Fim de semana A** ou **Fim de semana B** — os grupos se alternam: quem trabalha em um
     fim de semana folga no próximo;
   - **Todos os fins de semana** — o staff trabalha todo sábado e domingo.
4. **Salvar escala** — o bot passa a usar a nova escala imediatamente.

O modal mostra ainda qual grupo é o **desta semana** e se o staff trabalha ou folga, e o
cabeçalho de *Escala cadastrada* repete essa informação. Turnos que cruzam a meia-noite são
aceitos (`22:00` → `02:00`) e, no fim de semana, valem para **sábado e domingo**.

> O revezamento é semanal: cada semana do calendário (segunda a domingo) pertence ao grupo A ou
> B, alternando sempre. Um staff do grupo A só tem turno previsto nos fins de semana A — nos
> fins de semana B ele não conta atraso/saída antecipada, não recebe DM de aviso e não aparece
> na escala daquela semana no webhook. O mesmo vale para o grupo B.

Pelo Discord, `/banco escala` aceita o parâmetro opcional **grupo** (`A`, `B` ou *todos*) para
os dias de sábado/domingo; nos dias úteis ele só cadastra o turno daquele dia.

> O staff aparece no painel assim que tem **nome**, escala cadastrada ou status registrado.
> Para cadastrar alguém novo, use `/banco escala` uma vez com o membro ou defina o nome pelo
> painel no botão **Definir nome** da linha dele.

### API (mesma origem, exige sessão)

| Método | Rota | Descrição |
| --- | --- | --- |
| POST | `/api/login` | `{ "password": "..." }` → cookie `vantus_session` (HttpOnly, SameSite=Strict, 12h) |
| POST | `/api/logout` | encerra a sessão |
| GET | `/api/overview?from&to` | staff + status + escala + horas |
| GET | `/api/report?from&to` | relatório agregado por staff |
| GET | `/api/sessions?userId&from&to` | sessões detalhadas |
| GET | `/api/absences?from&to` | não entrada em serviço: `absences` (dia, staff, turno, `status` `ATRASADO`/`FALTOU`/`ATRASOU`, `lateMinutes`) + `alert` (tolerância, cargos e canal) |
| GET | `/api/evaluations?from&to&staffId` | avaliações do período: `entries`, `total`, `average`, `positiveRate`, `byRating`, `byStaff`, `channelId`, `staffOptions`, `alertMinAverage` |
| PUT | `/api/evaluations/channel` | `{ channelId }` — define o canal que recebe as avaliações (`null`/`""` desliga) |
| PUT | `/api/evaluations/alert` | `{ minAverage }` — limite (0–4) do aviso de média baixa; `0` desliga |
| PUT | `/api/staff/:userId/shifts` | `{ staffName, shifts: [{ weekday, start, end, parity? }] }` — `parity` = `A`/`B` para fim de semana revezado |
| PUT | `/api/staff/:userId/name` | `{ staffName }` — define o nome exibido (`""` volta ao nome do Discord) |
| PUT | `/api/staff/:userId/block` | `{ blocked, reason? }` — bloqueia/desbloqueia o staff de entrar em serviço (encerra a sessão e deixa indisponível); 409 se estiver atendendo |
| DELETE | `/api/staff/:userId` | remove o staff da equipe (apaga status, nome e escala; histórico de horas é mantido); 409 se estiver atendendo |
| POST | `/api/staff/:userId/off-service` | `{ disconnectVoice?, notify? }` — encerra a sessão e marca INDISPONÍVEL; responde 409 (`EM_ATENDIMENTO`) se o staff estiver atendendo |
| POST | `/api/staff/:userId/reset-hours` | **zera as horas** de um staff: `{ ok, message, staffName, sessions, restarted }` |
| POST | `/api/hours/reset` | **zera as horas de toda a equipe**: `{ ok, message, sessions, restarted }` |
| GET | `/api/schedule` | agenda da central: `schedule` (7 dias), `days` (com rótulos), `centralManual`, `status` (`open`, `manual`, `label`, `nextOpen`, `today`), `timezone` |
| PUT | `/api/schedule` | `{ schedule? , centralManual? }` — salva horários e/ou estado da central (`auto`/`open`/`closed`); 400 em `HH:MM` inválido, abertura = fechamento ou dia desconhecido |
| PUT | `/api/central` | `{ state, reason? }` — `closed` fecha a central mesmo dentro do horário, `open` abre fora dele, `auto` volta ao horário; devolve o payload de `/api/schedule` + `message` e `queueCleared` |
| GET | `/api/schedule/webhook` | webhook + envio automático (`{ url, configured, auto, day, dayLabel, time, lastWeek }`) |
| PUT | `/api/schedule/webhook` | `{ url, auto, day, time }` — campos omitidos são mantidos (`url: ""` remove e desliga o automático) |
| POST | `/api/schedule/send` | publica a escala da semana no webhook |
| DELETE | `/api/staff/:userId/shifts` | remove a escala |
| GET | `/api/health` | verificação de disponibilidade |

Proteções: senha comparada em tempo constante, limite de 8 tentativas por IP a cada 5 minutos,
cookie `HttpOnly` (`SameSite=Lax` em HTTP, `SameSite=None; Secure` quando acessado por HTTPS/proxy),
`Cache-Control: no-store` nas respostas da API.

### Acesso dentro de iframe / proxy (preview)

Em iframes de terceiros o navegador bloqueia **cookies** e **sessionStorage**, o que derrubava o
login com "Sessão expirada" logo após autenticar. O painel resolve isso em camadas:

| Camada | Quando é usada |
| --- | --- |
| Token em memória | sempre (mesma aba, enquanto a página estiver aberta) |
| `sessionStorage` | navegador normal (com storage liberado) |
| Token assinado no **hash da URL** (`#auth=…`) | quando o storage está bloqueado — sobrevive ao reload |

O token é **assinado com HMAC** derivado da senha (`WEB_PANEL_PASSWORD`), então continua válido
mesmo que o processo reinicie — e passa a ser inválido se a senha mudar. A autenticação chega ao
servidor por `Authorization: Bearer`, por `?auth=` ou por cookie (`SameSite=None; Secure` em HTTPS).
O logout revoga o token imediatamente.

O painel também é servido sem `X-Frame-Options` e com `Content-Security-Policy: frame-ancestors *`,
e os assets saem com `no-store` + versão (`app.js?v=…`, `styles.css?v=…`) para nunca rodar um JS ou
CSS antigo em cache. A versão é o hash dos três arquivos de `src/web/public`.

> Como o token pode ir no hash da URL em modo de contingência, evite compartilhar o link do painel
> enquanto estiver logado; ao sair (**Sair**) ele é removido.

## Comandos no Discord

```bash
/banco ver                       # suas horas, escala, atrasos e próximo turno
/banco staff membro:@fulano      # banco de horas de um membro da equipe
/banco equipe                    # resumo dos últimos 7 dias (admin)
/banco escala membro:@fulano dia:Segunda inicio:12:00 fim:18:00   # adiciona um turno (admin)
/banco limpar membro:@fulano     # remove a escala (admin)
```

### Bloquear e remover staff### Bloquear e remover staff

Na tabela **Equipe**, cada staff tem dois botões administrativos:

| Ação | O que acontece |
| --- | --- |
| **Bloquear** | o staff sai de serviço agora (sessão encerrada, desconectado do canal de trabalho) e **não consegue mais ficar disponível**: `/status disponível`, o menu do painel da equipe e a entrada no canal de atendimento são recusados até o desbloqueio. Continua na equipe, aparece como **BLOQUEADO** no painel do Discord e recebe uma DM com o motivo |
| **Remover** | apaga o cadastro do staff (status, nome e escala). Ele sai do painel da equipe e do banco de horas. O **histórico** de horas e atendimentos já registrados continua nos relatórios |

Ambas as ações são recusadas com erro **409** quando o staff está atendendo alguém — finalize ou
transfira o atendimento antes. Tudo fica registrado no canal de log (`STAFF_BLOCK`, `STAFF_UNBLOCK`,
`STAFF_REMOVE`).

## Escala aparece no painel da equipe

O bloco **EQUIPE** do painel da central mostra o **horário da escala** de cada staff na linha, no
lugar do status de disponibilidade:

```
DE SERVIÇO (2)
@staff — hoje 14:00 às 22:00
@staff — hoje 12:00 às 20:00 • em atendimento

FORA DE SERVIÇO (2)
@staff — amanhã 14:00 às 22:00
@staff — sem escala
```

Regras do texto (`describeSchedule`, `systems/hourbank/shiftSchedule.js`):

| Situação | Como aparece |
| --- | --- |
| Turno acontecendo agora | `em turno até 22:00` |
| Turno(s) de hoje | `hoje 14:00 às 22:00` (dois turnos: `hoje 08:00 às 12:00 / 18:00 às 22:00`) |
| Próximo turno amanhã | `amanhã 14:00 às 22:00` |
| Próximo turno em até 7 dias | `Qua 14:00 às 22:00` |
| Nenhum turno cadastrado | `sem escala` |

- O revezamento de fim de semana (grupos A/B) é respeitado: um turno da semana oposta não aparece
  como "hoje".
- **Ordem da lista**: a EQUIPE é ordenada pelo horário mostrado, do turno mais cedo para o mais tarde
  (`13:12 → 15:36 → 16:48 → 20:24`). O `scheduleSummary()` devolve `sortKey` = início do turno que
  gerou a linha; turno de amanhã fica depois de qualquer turno de hoje e `sem escala` (chave infinita)
  vai para o fim do grupo. Empate de horário desempata por status e depois por id, para a lista não
  ficar trocando de ordem a cada atualização.
- Os rótulos DISPONÍVEL / INDISPONÍVEL / AUSENTE saíram da linha — o grupo *DE SERVIÇO* /
  *FORA DE SERVIÇO* já informa a disponibilidade. Continuam apenas `• em atendimento` e
  `• bloqueado`, que não são disponibilidade.
- A escala é cadastrada no painel web (`PUT /api/staff/:id/shifts`) ou pelo webhook da escala; o
  painel do Discord só reflete o que está salvo.

## Painel web: escala fixa × apoio

A tabela de staff do painel web é dividida em dois grupos:

| Grupo | Quem entra | O que significa |
| --- | --- | --- |
| **Escala fixa** | staff com algum cargo de `staff_panel_role_ids` (ex. `1566903220968624188`) | têm horário de atendimento cadastrado e são cobrados por ele |
| **Apoio** | todo o resto da equipe | atendem em horários aleatórios, sem escala fixa |

- A tabela do painel web é a **união** de duas fontes, igual à EQUIPE do Discord: todos os staff
  cadastrados (`staff_status`, que formam o grupo *Apoio* quando não têm o cargo) **+** os membros que
  têm o cargo e nunca entraram em serviço (grupo *Escala fixa*, com `sem escala`).
- O agrupamento usa o **mesmo** `staff_panel_role_ids` do painel do Discord — um só lugar para configurar.
- Os cargos são sincronizados do Discord no `/api/overview` (throttle interno de 20s); falha de API não
  quebra o painel, o cache anterior continua valendo.
- **Sem cargo configurado** (ou cache ainda vazio), o painel cai na regra "tem turno cadastrado?":
  quem tem escala cadastrada aparece em *Escala fixa*, o resto em *Apoio*. O cabeçalho avisa quando
  os cargos ainda não sincronizaram.
- Staff com o cargo mas **sem turno** continua em *Escala fixa* e mostra `sem escala` na coluna do
  turno — é justamente a pendência de cadastro.
- A exportação CSV ganhou a coluna `grupo` (`escala` / `apoio`).

## Filtro da EQUIPE por cargo

O bloco **EQUIPE** do painel da central lista **todo mundo que tem o cargo** definido em
`staff_panel_role_ids` — inclusive quem nunca entrou em serviço. Sem nenhum cargo configurado, todos os
staff cadastrados aparecem (comportamento antigo).

A lista é a **união** de duas fontes:

| Fonte | Quem é | Como aparece |
| --- | --- | --- |
| `staff_status` + cargo | staff que já entrou em serviço alguma vez | com o status real e o horário da escala |
| **só o cargo** | membro do Discord com o cargo, sem status registrado | em **FORA DE SERVIÇO**, com `sem escala`, até entrar em serviço |

Sem essa segunda fonte a EQUIPE mostrava uma equipe menor do que a real: quem recebia o cargo depois
do último cadastro simplesmente não aparecia no painel. A linha vem marcada com `registered: false`
em `StaffService.listForPanel()`, e **não** conta como disponível — a entrada na fila continua exigindo
alguém realmente em serviço (`staffCounts.DISPONIVEL`). Membros que perdem o cargo saem do painel na
próxima sincronização (a cada 5 minutos, ou na hora via `guildMemberUpdate`).

```bash
# .env (aplicado no boot) ou /config definir chave:staff_panel_role_ids valor:["1566903220968624188"]
STAFF_PANEL_ROLE_IDS=1566903220968624188
```

- Aceita vários cargos separados por vírgula: qualquer um deles coloca a pessoa no painel.
- O cache de cargos é carregado no boot, atualizado a cada 5 minutos e imediatamente quando alguém
  recebe ou perde um cargo (`guildMemberUpdate`). Só os membros com esses cargos são consultados,
  o que deixa a sincronização leve e menos sujeita a limite de requisições do Discord.
- Enquanto o cache ainda não existe (primeiros segundos após o boot), ninguém é escondido.
- Os contadores de staff seguem a mesma lista: o painel nunca mostra "3 na equipe" listando 2.
- **O painel nunca esvazia a equipe por falha de sincronização.** Se o Discord recusar a consulta
  (limite de requisições, queda momentânea) ou devolver uma lista vazia, o bot mantém a última
  lista boa — antes, esse vazio entrava no cache e a EQUIPE desaparecia, os *Disponíveis* iam para 0
  e a entrada na fila ficava bloqueada até a próxima sincronização (o sintoma "sumiu a equipe e
  voltou do nada"). Com `staff_panel_role_ids` configurado e o cache vazio,
  o painel lista todos os staff registrados em vez de não listar ninguém.
- **Diagnóstico**: `/diagnostico` mostra `EQUIPE do painel (cargos)` com quantos membros foram
  carregados, há quanto tempo ocorreu a sincronização e o último erro (se houver).

## Configurações

| Chave | Padrão | Descrição |
| --- | --- | --- |
| `hour_bank_enabled` | `true` | Liga/desliga a contagem automática |
| `staff_panel_role_ids` | `[]` (todos) | Cargos que aparecem em **EQUIPE** no painel da central |
| `schedule` | modelo padrão | Agenda da central (editável no painel web) |
| `central_manual` | `auto` | Força a central aberta/fechada ignorando a agenda |
| `hour_bank_reminder_minutes` | `5` | Antecedência do aviso por DM (`0` desliga) |
| `hour_bank_max_session_hours` | `12` | Limite para fechamento automático da sessão |
| `hour_bank_absence_minutes` | `10` | Tolerância após o início do turno antes de registrar a falta/atraso (`0` desliga) |
| `hour_bank_absence_catchup_hours` | `12` | Janela para registrar turnos perdidos enquanto o bot estava offline |
| `hour_bank_absence_role_ids` | `["1560793864330158240", "1566903222088499251"]` | Cargos avisados no Discord |
| `hour_bank_absence_channel_id` | `1566903219915858102` (canal de logs) | Canal do aviso (vazio = `log_channel_id`; sem ele, canal da staff) |

```bash
/config definir chave:hour_bank_reminder_minutes valor:10
/config definir chave:hour_bank_enabled valor:false
```

## Prévia local com dados de exemplo

```bash
npm run preview:web     # http://localhost:8080 • senha: vantus
```

O script usa um banco separado (`data/preview-web.sqlite`) — nenhum dado real é tocado.

## Problemas comuns

| Sintoma | Causa / solução |
| --- | --- |
| Não conta horas | staff precisa estar **DISPONÍVEL** (ou em atendimento); confira `/banco ver` |
| Staff não aparece no fim de semana | ele está no outro grupo do revezamento (A/B) — confira o grupo na **Escala cadastrada** |
| DM de aviso não chega | staff com DM fechada; `hour_bank_reminder_minutes` igual a `0`; turno cadastrado para outro dia |
| Atraso zerado | o staff entrou **antes** ou exatamente no início do turno, ou não havia turno naquele horário |
| Painel não abre | `WEB_PANEL_PASSWORD` vazio (painel desligado) ou porta bloqueada — veja o log `web` do bot |
| Tela em branco no preview/iframe | era bloqueio de `X-Frame-Options` — corrigido; se persistir, rode `LOG_LEVEL=debug` e confira `GET /` no log |
| Login "não aceita" e volta para a tela de senha | corrigido: token assinado em memória/hash, aceito via header, query ou cookie. Se aparecer, clique em **Recarregar** na própria tela (limpa cache do JS antigo) |
| Entra, mas a tela de senha **continua na frente** do painel | era CSS: `.login { display: grid }` vencia o atributo `hidden`. Corrigido com `[hidden] { display: none !important }`; há teste de regressão do CSS |
| Mensagem "unauthorized" ao errar a senha | corrigido: o login mostra o texto do servidor (**Senha incorreta.**) e o botão fica em "Entrando…" durante a requisição |
| Escala automática não chegou | `hour_bank_webhook_auto` desligado, webhook vazio, ou o dia/horário escolhido ainda não chegou — confira o painel e o log `hourbank` |
| Webhook recusa a escala | URL copiada incompleta, webhook apagado/canal sem permissão ou mensagem enviada por outro bot — confira a mensagem do painel (HTTP 400/404) |
| Horas erradas após queda do bot | a sessão é fechada no limite de `hour_bank_max_session_hours`; ajuste manualmente a escala/horário pelo painel |

## Log do painel

Cada requisição é registrada com escopo `web`:

```
[DEBUG] [web] GET / → 200 (2ms)
[DEBUG] [web] GET /api/overview → 200 (3ms)
[WARN]  [web] GET /api/overview → 401 (0ms)     ← sem sessão (normal antes do login)
[ERROR] [web] GET /api/overview → 500 (12ms)    ← erro real, com stack no log
```

Para ver tudo: `LOG_LEVEL=debug npm start` (ou `LOG_LEVEL=debug npm run preview:web`).

## Estrutura no código

| Arquivo | Responsabilidade |
| --- | --- |
| `src/systems/hourbank/hourBankService.js` | sessões, atrasos, relatórios, avisos |
| `src/systems/hourbank/shiftSchedule.js` | escala semanal, turnos que viram o dia, próximas ocorrências |
| `src/database/repositories/hourBankRepository.js` | persistência (escala, sessões, avisos) |
| `src/web/server.js` | HTTP, autenticação e API |
| `src/web/public/*` | interface (HTML/CSS/JS, sem build) |
| `src/commands/staff/banco.js` | `/banco ...` |
| migração **v5 `banco_de_horas`** | tabelas `staff_shifts`, `staff_sessions`, `staff_shift_reminders` |
| migração **v10 `nao_entrada_em_servico`** | tabela `staff_absences` (uma linha por turno perdido) |

## Não entrada em serviço (faltas e atrasos)

O bot compara a **escala** com as **sessões reais** a cada minuto:

1. passou `hour_bank_absence_minutes` do início do turno e o staff não tem nenhuma sessão que
   encoste na janela do turno (quem já estava disponível desde antes conta como presente);
2. o bot grava uma linha em `staff_absences` e envia **um** aviso no **canal de logs de atendimento** marcando os
   cargos de `hour_bank_absence_role_ids`;
3. se o staff entrar em serviço depois (ainda dentro do turno), o registro passa a `ATRASOU`;
4. se o turno terminar sem ele, o registro fica `FALTOU`.

O aviso acontece **uma vez por turno** (`notified_at`), então reiniciar o bot não repete a
mensagem. Turnos que terminaram enquanto o bot estava fora ainda são registrados, dentro de
`hour_bank_absence_catchup_hours`.

```bash
# trocar a tolerância e desligar o aviso no Discord
/config definir chave:hour_bank_absence_minutes valor:15
/config definir chave:hour_bank_absence_role_ids valor:[]

# canal específico para o aviso (padrão: canal de logs de atendimento)
/config definir chave:hour_bank_absence_channel_id valor:123456789012345678
/config definir chave:hour_bank_absence_channel_id valor:""  # volta ao canal de logs
```
