# 04 • Guia do jogador

## Como pedir atendimento

Existem dois caminhos — os dois funcionam:

**Opção A — pelo painel**
1. Entre no canal de voz **⏳・aguardando-atendimento**.
2. Vá até o canal **#central-atendimento** e clique em **🎫 ENTRAR NA FILA**.
3. Você é colocado na fila e confirmado no canal de espera.

> **O botão só funciona para quem está na call de espera.** Se você clicar fora dela, o bot avisa
> qual canal entrar e não coloca você na fila. O mesmo vale para `/entrar`.

**Opção B — só entrando no canal de voz**
1. Entre direto no canal **⏳・aguardando-atendimento**.
2. O bot **te coloca na fila automaticamente**: você recebe o protocolo e a posição no privado.

Em qualquer caso: quando um staff te chamar, você recebe uma mensagem privada e é movido
automaticamente para o canal de atendimento.

## O que aparece na mensagem privada

```
Você entrou na fila de atendimento da VANTUS.

Protocolo: #0001
Posição na fila: 1º

Permaneça no canal de espera. Nossa equipe realizará seu atendimento assim que possível.
```

Você também é avisado quando sua posição melhora — sem spam: os avisos respeitam um intervalo mínimo.

## Durante o atendimento

- Você é movido para o canal de voz do staff que te chamou.
- Só você tem acesso àquele canal naquele momento (outros jogadores da fila não entram).
- Você tem alguns minutos para comparecer ao canal. Se não aparecer, o protocolo é encerrado
  como **JOGADOR NÃO COMPARECEU** e você pode voltar à fila.

## Desistindo

- Clique em **❌ SAIR DA FILA** no painel ou use `/sair`.
- **O botão Entrar na Fila fica desabilitado quando a central está fechada ou quando nenhum staff
  está em serviço.** Nesse caso não é possível entrar na fila (nem pelo botão, nem por `/entrar`,
  nem entrando no canal de voz) — tente novamente mais tarde.
- **Sair do canal de espera remove você da fila na hora** — inclusive se você for movido para
  outro canal ou cair a conexão.
- **Ninguém é expulso do canal**: ao sair da fila o bot não desconecta você e não bloqueia a volta —
  pode entrar no canal de espera e na fila de novo na mesma hora.
- Seu protocolo é encerrado como **JOGADOR DESISTIU**.
- Se você sair do servidor, o bot remove você da fila automaticamente.

## Depois do atendimento

Você recebe uma avaliação no privado:

> Como foi seu atendimento pela equipe VANTUS?
> ⭐ Muito bom · ⭐ Bom · ⭐ Regular · ⭐ Ruim

Sua nota fica vinculada ao protocolo e ao staff responsável. Você pode avaliar apenas uma vez por atendimento.

Se você fechou as mensagens privadas (ou perdeu a DM), existem duas saídas:

1. **Botão “Avaliar atendimento” no painel da central** — mostra as notas do(s) atendimento(s)
   encerrado(s) que ainda estão sem avaliação.
2. **Comando** (o protocolo é opcional; sem ele, o bot usa o último atendimento pendente):

```
/avaliar protocolo:12 nota:Muito bom
/avaliar nota:Bom
```

Com a DM fechada, o próprio bot publica a avaliação no canal do painel marcando você com as
quatro notas — dá para avaliar direto por lá.

A avaliação aparece no painel web da equipe (média, distribuição e ranking por atendente) e no
canal de avaliações do servidor.

## Comandos

| Comando | O que faz |
| --- | --- |
| `/entrar` | entra na fila |
| `/sair` | sai da fila |
| `/avaliar` | avalia o último atendimento pendente (ou o protocolo informado) |
| `/posicao` | mostra posição, tempo de espera e previsão |
| `/protocolo` | consulta seu protocolo mais recente (ou `/protocolo numero:12`) |
| `/ajuda` | resumo das regras e horários |

## Quando a central está fechada

O botão recusa novas entradas e informa o próximo horário de abertura. Atendimentos já iniciados
continuam normalmente. Confira os horários no painel ou em `/ajuda`.

## Boas práticas

- Fique no canal de espera até ser chamado — sair dele encerra sua posição.
- Não abra protocolo sem necessidade real; cada entrada fica registrada no histórico.
- Mantenha as mensagens privadas abertas para receber as notificações.
