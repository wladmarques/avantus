# 05 • Guia da equipe (staff)

O painel da equipe fica em **#painel-staff** e é atualizado automaticamente.

## Antes de atender

1. Entre em um dos canais **🔉・suporte¹**, **🔉・suporte²** ou **🔉・suporte³**.
2. Confirme seu status com **🟢 MEU STATUS** → *Disponível* (ou `/status situacao:Disponível`).

> **Regra de ouro:** o bot só permite chamar um jogador se você estiver conectado a um canal
> de voz válido da central. Sem isso, ele responde:
> *“Você precisa estar conectado a um canal de voz de atendimento para chamar um jogador.”*

## Chamar jogadores

**📞 CHAMAR** — pega automaticamente o primeiro da fila, move o jogador para o seu canal,
registra o início e muda seu status para 🔴 EM ATENDIMENTO.

**👤 ESCOLHER** — escolhe qualquer jogador da fila. O **motivo é obrigatório** e fica
registrado como alteração da ordem (aparece com ⚠️ no painel e nos logs).

**Múltiplos atendimentos:** cada staff atende um jogador por vez. Admins podem liberar mais de um
por staff com `/config definir chave:allow_staff_multi valor:true`.

## Durante o atendimento

- O jogador aparece em **📞 EM ATENDIMENTO** com protocolo, staff, horário e duração.
- **Presença:** ✅ confirmada quando ele entra no canal / ⏳ aguardando.
- Se o jogador cair do canal, há uma tolerância (`voice_disconnect_grace_seconds`, padrão 120s).
  Passado o tempo, o protocolo é encerrado como **JOGADOR DESCONECTOU**.
- Se você cair do canal, seu status vai para ⚫ INDISPONÍVEL. Se não voltar dentro da tolerância,
  o protocolo é encerrado como **STAFF DESCONECTOU** e o jogador volta para a fila.

## Ações disponíveis

Os botões ficam em **duas linhas**, na ordem em que você usa durante o atendimento:

```
[ CHAMAR ]  [ ESCOLHER ]  [ PULAR ]  [ DEVOLVER ]  [ FINALIZAR ]
[ ATUALIZAR ]  [ MEU STATUS ]  [ REATIVAR ]  [ REMOVER ]
```

| Botão | Efeito |
| --- | --- |
| ✅ CHAMAR | chama o primeiro da fila |
| 👤 ESCOLHER | chama um jogador específico da fila — **motivo obrigatório** |
| ⏭️ PULAR | move o jogador para o final da fila ou o mantém pendente (conforme configuração) — **motivo obrigatório** |
| 🔄 DEVOLVER | o jogador volta ao **final** da fila e você é liberado |
| ✅ FINALIZAR | encerra seu atendimento, calcula duração, envia a avaliação ao jogador (DM ou canal do painel, se a DM estiver fechada) e libera você |
| 🔄 ATUALIZAR | força a atualização das informações |
| 🟢 MEU STATUS | altera sua disponibilidade |
| ▶️ REATIVAR | devolve um jogador pendente para a fila |
| 🚫 REMOVER | remove o jogador (fila ou atendimento) com **justificativa obrigatória** |

> Os rótulos são curtos de propósito: o Discord define a largura do botão pelo tamanho do texto, então
> rótulos de tamanho parecido (5 a 10 caracteres) deixam as duas linhas alinhadas. Os botões que não se
> aplicam ao momento (sem fila, sem atendimento) aparecem desabilitados, sem mudar de tamanho.

> A administração pode **bloquear** você pelo painel web. Enquanto o bloqueio estiver ativo, o
> `/status situacao:Disponível` (e entrar no canal de atendimento) não coloca você em serviço — fale
> com um administrador. Também é possível ser **removido da equipe** pelo painel.

## Seus status

| Status | Quando usar |
| --- | --- |
| 🟢 DISPONÍVEL | pronto para receber chamadas |
| 🔴 EM ATENDIMENTO | aplicado automaticamente quando você chama alguém |
| 🟡 AUSENTE | pausa curta (almoço, AFK) |
| ⚫ INDISPONÍVEL | fora de serviço |

**Entrar no canal de voz de atendimento não coloca você em serviço.** Quem decide é você: no painel
da equipe, clique em **MEU STATUS** e escolha **Disponível** (ou use
`/status situacao:Disponível`). Enquanto estiver fora de serviço:

- você **não** aparece como disponível no painel nem entra na contagem de staffs;
- **não** é possível chamar jogador — o bot responde pedindo para você entrar em serviço (isso evita
  atender sem o banco de horas contando);
- o banco de horas só começa a contar quando você fica DISPONÍVEL.

Ao finalizar um atendimento, você volta para 🟢 DISPONÍVEL — **exceto** se você mesmo definiu 🟡 AUSENTE
ou ⚫ INDISPONÍVEL (sua escolha é respeitada).

## Aviso de fila parada

Se alguém ficar mais de **3 minutos** na sala **⏳・aguardando-atendimento** sem ser chamado, todo
staff **disponível** recebe uma DM com o protocolo, o nome do jogador e há quanto tempo ele espera.
O aviso sai uma única vez por jogador (não vira spam) e é registrado no canal de logs.
Administração pode mudar o tempo (ou desligar com `0`) em
`/config definir chave:wait_alert_minutes`.

## Comandos de staff

| Comando | Uso |
| --- | --- |
| `/chamar` | chama o próximo |
| `/chamar jogador:@fulano motivo:...` | chama fora da ordem (motivo obrigatório) |
| `/finalizar observacao:...` | encerra seu atendimento com observação |
| `/devolver motivo:...` | devolve o jogador ao final da fila |
| `/pular jogador:@fulano motivo:...` | pula um jogador |
| `/status situacao:Disponível` | altera sua disponibilidade |

## Boas práticas

- Finalize sempre ao terminar: protocolo aberto trava sua próxima chamada.
- Use **Chamar específico** apenas em situações justificadas — o log registra quem alterou a ordem e por quê.
- Não remova jogadores sem justificativa real: toda ação fica no histórico administrativo.
- Deixe a disponibilidade em ⚫ INDISPONÍVEL ao sair de serviço, para não distorcer a espera média.

## Banco de horas

Enquanto você estiver **em serviço**, o bot conta o seu tempo automaticamente:

- ficar **Disponível** (`/status`) abre a sessão; entrar **Em atendimento** mantém a contagem;
- ficar **Ausente** ou **Indisponível** (ou sair do canal) encerra a sessão;
- **5 minutos antes** do turno cadastrado na sua escala você recebe uma **DM de aviso**;
- atrasos são medidos em relação ao início do turno cadastrado.

Consulte a qualquer momento:

```bash
/banco ver
```

Para ver as horas de um colega (equipe): `/banco staff membro:@fulano`.

O painel web mostra o detalhamento completo (entrada, saída, horas por dia, atrasos e sessões).
Se a sua escala estiver errada, peça à administração para ajustar em `/banco escala` ou no painel.
