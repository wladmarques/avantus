const fs = require('node:fs');
const { createTestEnv } = require('/home/user/avantus/tests/helpers');
const { createWebServer } = require('/home/user/avantus/src/web/server');
const origErr = console.error;
console.error = (...a) => { origErr('ERR', ...a); };
process.on('unhandledRejection', (e) => origErr('UNHANDLED', e));
const APP = '/home/user/avantus/src/web/public/app.js';

function createElement(tag='div'){return{tagName:tag,children:[],dataset:{},style:{},listeners:{},classList:{add(){},remove(){},toggle(){},contains:()=>false},addEventListener(t,f){(this.listeners[t]=this.listeners[t]||[]).push(f);},removeEventListener(){},appendChild(c){this.children.push(c);return c;},append(...n){this.children.push(...n);},remove(){},querySelectorAll:()=>[],querySelector:()=>null,closest:()=>null,showModal(){},close(){},setAttribute(){},getBoundingClientRect:()=>({top:0,left:0,right:0,bottom:0,width:0,height:0}),set innerHTML(v){this._html=v;this.children=[];},get innerHTML(){return this._html||'';},textContent:'',value:'',hidden:false};}
function createDocument(){const r=new Map();return{registry:r,getElementById(id){if(!r.has(id)){const n=createElement();n.id=id;r.set(id,n);}return r.get(id);},createElement:(t)=>createElement(t),querySelectorAll:()=>[]};}

(async () => {
  const env = await createTestEnv();
  const { server } = createWebServer({ services: env.services, env: { guildId: env.guildId }, password: 'vantus' });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const bf = async (url, options = {}) => {
    const abs = url.startsWith('http') ? url : `${base}${url}`;
    const r = await fetch(abs, options);
    const text = await r.text();
    let json = null; try { json = JSON.parse(text); } catch {}
    return { ok: r.ok, status: r.status, headers: { get: (n) => r.headers.get(n) }, json: async () => json, text: async () => text };
  };
  await env.services.staff.setStatus({ guildId: env.guildId, userId: '900000000000000777', status: 'DISPONIVEL', updatedBy: 'teste', manual: false });
  await env.services.hourBank.setDisplayName({ guildId: env.guildId, userId: '900000000000000777', staffName: 'esquecido' });
  const login = await bf('/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ password: 'vantus' }) });
  const lj = await login.json();
  console.log('login', login.status, Object.keys(lj));
  const token = lj.token;
  let source = fs.readFileSync(APP, 'utf8');
  source = source.replace('toast(error.message);', 'console.log("ERR-STACK", error && error.stack); toast(error.message);');
  const doc = createDocument();
  const location = { href: `https://x/p/#auth=${token}`, hash: `#auth=${token}` };
  const win = { location, history: { replaceState(_s,_t,url){ const u=new URL(url); location.href=u.toString(); location.hash=u.hash; } }, addEventListener(){}, innerWidth: 1400, innerHeight: 900 };
  const run = new Function('document','window','sessionStorage','fetch','URL','Blob','setTimeout','setInterval','clearInterval','clearTimeout','console', source);
  try { run(doc, win, { getItem(){throw new Error('x');}, setItem(){throw new Error('x');}, removeItem(){throw new Error('x');} }, bf, URL, function(){}, setTimeout, () => 0, () => {}, () => {}, console); } catch (e) { console.log('THROW', e); }
  await new Promise((r) => setTimeout(r, 200));
  doc.getElementById('password').value = 'vantus';
  try { await doc.getElementById('login-form').listeners.submit[0]({ preventDefault(){} }); } catch(e){ console.log('LOGIN THROW', e); }
  await new Promise((r) => setTimeout(r, 600));
  console.log('toast:', doc.getElementById('toast').textContent);
  console.log('app hidden:', doc.getElementById('app').hidden, '| login hidden:', doc.getElementById('login').hidden);
  const rows = doc.getElementById('staff-body').children;
  console.log('rows:', rows.length);
  for (const tr of rows) console.log(JSON.stringify(tr.className), tr.children[0]?.children[0]?.children.map(c=>c.textContent));
  await new Promise((r) => server.close(r));
  await env.cleanup();
})();
